/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'cogni-blue': '#00d4ff',
        'cogni-teal': '#00ffc8',
        'cogni-dark': '#0a0a0f',
        'cogni-card': '#12121a',
      }
    },
  },
  plugins: [],
}
