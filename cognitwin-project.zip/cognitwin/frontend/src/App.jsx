import { useState, useEffect } from 'react'
import axios from 'axios'
import Dashboard from './components/Dashboard'
import TypingArea from './components/TypingArea'
import CrisisSupport from './components/CrisisSupport'
import BehaviorDiary from './components/BehaviorDiary'
import AgentExplainer from './components/AgentExplainer'

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000'

function App() {
  const [session, setSession] = useState(null)
  const [state, setState] = useState({
    cognitive_load: 0,
    mood_drift: 0,
    decision_stability: 1,
    risk_volatility: 0,
    heat_index: 0,
    rage_index: 0
  })
  const [agentResult, setAgentResult] = useState(null)
  const [isConnected, setIsConnected] = useState(false)
  const [error, setError] = useState(null)
  const [activeTab, setActiveTab] = useState('monitor')
  const [isLocked, setIsLocked] = useState(false)

  // Check for PIN lock on mount
  useEffect(() => {
    const hasPin = localStorage.getItem('cognitwin_pin')
    if (hasPin) setIsLocked(true)
  }, [])

  // Create session on mount
  useEffect(() => {
    if (!isLocked) createSession()
  }, [isLocked])

  // Poll for state updates
  useEffect(() => {
    if (!session || isLocked) return

    const interval = setInterval(() => {
      fetchState()
    }, 1000)

    return () => clearInterval(interval)
  }, [session, isLocked])

  const createSession = async () => {
    try {
      const response = await axios.post(`${API_URL}/consent`, {})
      setSession(response.data)
      setIsConnected(true)
      setError(null)
    } catch (err) {
      setError('Failed to connect to CogniTwin server')
      setIsConnected(false)
    }
  }

  const fetchState = async () => {
    if (!session) return

    try {
      const response = await axios.get(
        `${API_URL}/state/${session.session_id}`,
        {
          headers: {
            Authorization: `Bearer ${session.consent_token}`
          }
        }
      )
      // Extract state and agent result
      const { agent, ...stateData } = response.data
      setState(stateData)
      if (agent) setAgentResult(agent)
    } catch (err) {
      console.error('Failed to fetch state:', err)
    }
  }

  const sendSignals = async (signals, textSnapshot) => {
    if (!session) return

    try {
      const response = await axios.post(
        `${API_URL}/ingest`,
        {
          session_id: session.session_id,
          signals: signals,
          text_snapshot: textSnapshot
        },
        {
          headers: {
            Authorization: `Bearer ${session.consent_token}`
          }
        }
      )
      // Update state and agent from response
      if (response.data.state) {
        setState(prev => ({ ...prev, ...response.data.state }))
      }
      if (response.data.agent) {
        setAgentResult(response.data.agent)
      }
    } catch (err) {
      console.error('Failed to send signals:', err)
    }
  }

  const handleAcknowledge = async () => {
    if (!session) return
    try {
      await axios.post(
        `${API_URL}/agent/${session.session_id}/acknowledge`,
        {},
        {
          headers: {
            Authorization: `Bearer ${session.consent_token}`
          }
        }
      )
      // Refresh state
      fetchState()
    } catch (err) {
      console.error('Failed to acknowledge:', err)
    }
  }

  const handleUpdateThreshold = async (name, value) => {
    if (!session) return
    try {
      await axios.post(
        `${API_URL}/agent/${session.session_id}/threshold?name=${name}&value=${value}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${session.consent_token}`
          }
        }
      )
      // Refresh state
      fetchState()
    } catch (err) {
      console.error('Failed to update threshold:', err)
    }
  }

  const handleLock = () => {
    const hasPin = localStorage.getItem('cognitwin_pin')
    if (hasPin) setIsLocked(true)
  }

  // Show lock screen if locked
  if (isLocked) {
    return <CrisisSupport isLocked={true} onUnlock={() => setIsLocked(false)} />
  }

  return (
    <div className="min-h-screen bg-cogni-dark text-white p-4 md:p-6">
      {/* Header */}
      <header className="max-w-7xl mx-auto mb-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-cogni-blue to-cogni-teal bg-clip-text text-transparent">
              CogniTwin
            </div>
            <span className="hidden md:inline text-gray-500 text-sm">Cognitive Digital Twin</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-red-500'}`} />
              <span className="text-sm text-gray-400 hidden md:inline">
                {isConnected ? 'Connected' : 'Disconnected'}
              </span>
            </div>
            {localStorage.getItem('cognitwin_pin') && (
              <button
                onClick={handleLock}
                className="text-gray-500 hover:text-white transition-colors"
                title="Lock"
              >
                🔒
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <nav className="flex gap-2 mt-4">
          {[
            { id: 'monitor', label: '📊 Monitor', mobileLabel: '📊' },
            { id: 'agent', label: '🤖 Agent', mobileLabel: '🤖' },
            { id: 'diary', label: '📓 Diary', mobileLabel: '📓' },
            { id: 'crisis', label: '🆘 Crisis', mobileLabel: '🆘' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? 'bg-cogni-blue text-black'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              <span className="hidden md:inline">{tab.label}</span>
              <span className="md:hidden">{tab.mobileLabel}</span>
            </button>
          ))}
        </nav>
      </header>

      {error && (
        <div className="max-w-7xl mx-auto mb-6 p-4 bg-red-500/20 border border-red-500/50 rounded-lg text-red-300">
          {error}
        </div>
      )}

      {/* Agent Action Banner */}
      {agentResult?.action && (
        <div className="max-w-7xl mx-auto mb-4 p-3 bg-gradient-to-r from-cogni-blue/20 to-cogni-teal/20 border border-cogni-blue/50 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-lg">{getActionIcon(agentResult.action.action)}</span>
            <div>
              <span className="text-white text-sm font-medium">
                {getActionLabel(agentResult.action.action)}
              </span>
              <span className="text-gray-400 text-xs ml-2">
                — {agentResult.action.why}
              </span>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('agent')}
            className="bg-cogni-blue/30 hover:bg-cogni-blue/50 text-white px-3 py-1 rounded text-sm transition-colors"
          >
            See Why
          </button>
        </div>
      )}

      <main className="max-w-7xl mx-auto">
        {/* Monitor Tab */}
        {activeTab === 'monitor' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-cogni-card rounded-2xl p-6 border border-gray-800">
              <h2 className="text-lg font-semibold mb-4 text-gray-300">Type Here</h2>
              <TypingArea onSignalBatch={sendSignals} />
              <p className="mt-4 text-sm text-gray-500">
                Type naturally. Your patterns are analyzed in real-time.
              </p>
            </div>

            <div className="bg-cogni-card rounded-2xl p-6 border border-gray-800">
              <h2 className="text-lg font-semibold mb-4 text-gray-300">Cognitive State</h2>
              <Dashboard state={state} />
            </div>
          </div>
        )}

        {/* Agent Tab - THE KEY DEMO TAB */}
        {activeTab === 'agent' && (
          <div className="bg-cogni-card rounded-2xl p-6 border border-gray-800 max-w-3xl mx-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-300">🤖 Agent Reasoning</h2>
              <span className="text-xs text-gray-500">Transparent • Explainable • User-Controlled</span>
            </div>
            <AgentExplainer
              agentResult={agentResult}
              onAcknowledge={handleAcknowledge}
              onUpdateThreshold={handleUpdateThreshold}
            />
          </div>
        )}

        {/* Diary Tab */}
        {activeTab === 'diary' && (
          <div className="bg-cogni-card rounded-2xl p-6 border border-gray-800 max-w-2xl mx-auto">
            <BehaviorDiary currentState={state} />
          </div>
        )}

        {/* Crisis Support Tab */}
        {activeTab === 'crisis' && (
          <div className="bg-cogni-card rounded-2xl p-6 border border-gray-800 max-w-2xl mx-auto">
            <CrisisSupport isLocked={false} onUnlock={() => {}} />
          </div>
        )}
      </main>

      {/* Session Info */}
      {session && (
        <footer className="max-w-7xl mx-auto mt-8 text-center text-gray-600 text-sm">
          Session: {session.session_id.slice(0, 8)}...
        </footer>
      )}
    </div>
  )
}

function getActionIcon(action) {
  const icons = {
    'calm_mode': '🌊',
    'suggest_break': '☕',
    'show_breathing': '🧘',
    'offer_support': '💬',
    'show_crisis_resources': '🆘',
    'alert_contacts': '🚨'
  }
  return icons[action] || '📋'
}

function getActionLabel(action) {
  const labels = {
    'calm_mode': 'Calm Mode',
    'suggest_break': 'Break Suggested',
    'show_breathing': 'Breathing Exercise',
    'offer_support': 'Support Available',
    'show_crisis_resources': 'Crisis Resources',
    'alert_contacts': 'Alerting Contacts'
  }
  return labels[action] || action
}

export default App
