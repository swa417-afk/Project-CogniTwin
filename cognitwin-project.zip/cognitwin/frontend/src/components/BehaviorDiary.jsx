import { useState, useEffect } from 'react'

const MOOD_OPTIONS = [
  { emoji: '😊', label: 'Good', value: 3, color: 'green' },
  { emoji: '😐', label: 'Okay', value: 2, color: 'yellow' },
  { emoji: '😔', label: 'Low', value: 1, color: 'orange' },
  { emoji: '😢', label: 'Bad', value: 0, color: 'red' },
]

const ACTIVITY_TAGS = [
  'Work', 'Exercise', 'Social', 'Sleep', 'Eating', 'Meditation', 
  'Screen time', 'Outdoors', 'Creative', 'Learning', 'Rest'
]

function BehaviorDiary({ currentState }) {
  const [entries, setEntries] = useState([])
  const [showNewEntry, setShowNewEntry] = useState(false)
  const [newEntry, setNewEntry] = useState({
    mood: null,
    note: '',
    tags: [],
    cognitiveSnapshot: null
  })
  const [viewMode, setViewMode] = useState('list') // 'list' or 'calendar'

  // Load entries from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('cognitwin_diary')
    if (saved) setEntries(JSON.parse(saved))
  }, [])

  // Save entries
  useEffect(() => {
    localStorage.setItem('cognitwin_diary', JSON.stringify(entries))
  }, [entries])

  // Auto-save cognitive state snapshot every hour
  useEffect(() => {
    if (currentState && currentState.cognitive_load > 0) {
      const lastAuto = entries.find(e => e.type === 'auto')
      const now = Date.now()
      
      // Auto-snapshot if last one was > 1 hour ago
      if (!lastAuto || now - lastAuto.timestamp > 3600000) {
        const autoEntry = {
          id: now,
          timestamp: now,
          type: 'auto',
          cognitiveSnapshot: { ...currentState },
          note: 'Auto-captured state'
        }
        // Keep only last 24 auto-snapshots
        const autoEntries = entries.filter(e => e.type === 'auto').slice(-23)
        const manualEntries = entries.filter(e => e.type !== 'auto')
        setEntries([...manualEntries, ...autoEntries, autoEntry])
      }
    }
  }, [currentState])

  const handleSaveEntry = () => {
    if (newEntry.mood === null) return

    const entry = {
      id: Date.now(),
      timestamp: Date.now(),
      type: 'manual',
      mood: newEntry.mood,
      note: newEntry.note,
      tags: newEntry.tags,
      cognitiveSnapshot: currentState ? { ...currentState } : null
    }

    setEntries([entry, ...entries])
    setNewEntry({ mood: null, note: '', tags: [], cognitiveSnapshot: null })
    setShowNewEntry(false)
  }

  const handleDeleteEntry = (id) => {
    setEntries(entries.filter(e => e.id !== id))
  }

  const toggleTag = (tag) => {
    if (newEntry.tags.includes(tag)) {
      setNewEntry({ ...newEntry, tags: newEntry.tags.filter(t => t !== tag) })
    } else {
      setNewEntry({ ...newEntry, tags: [...newEntry.tags, tag] })
    }
  }

  const formatDate = (timestamp) => {
    const date = new Date(timestamp)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return `Today ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    } else if (date.toDateString() === yesterday.toDateString()) {
      return `Yesterday ${date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })
  }

  const getMoodEmoji = (value) => {
    const mood = MOOD_OPTIONS.find(m => m.value === value)
    return mood ? mood.emoji : '❓'
  }

  const getStateColor = (value, metric) => {
    if (metric === 'mood_drift') {
      return value < -0.3 ? 'text-red-400' : value > 0.3 ? 'text-green-400' : 'text-yellow-400'
    }
    if (metric === 'decision_stability') {
      return value > 0.6 ? 'text-green-400' : value > 0.3 ? 'text-yellow-400' : 'text-red-400'
    }
    // For cognitive_load, risk_volatility, heat, rage - lower is better
    return value < 0.3 ? 'text-green-400' : value < 0.6 ? 'text-yellow-400' : 'text-red-400'
  }

  // Calculate weekly summary
  const weekAgo = Date.now() - 7 * 24 * 60 * 60 * 1000
  const weekEntries = entries.filter(e => e.timestamp > weekAgo && e.type === 'manual')
  const avgMood = weekEntries.length > 0 
    ? (weekEntries.reduce((sum, e) => sum + e.mood, 0) / weekEntries.length).toFixed(1)
    : null

  const manualEntries = entries.filter(e => e.type === 'manual').slice(0, 20)

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-gray-300 font-semibold flex items-center gap-2">
          <span>📓</span> Behavior Diary
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1 rounded text-xs ${viewMode === 'list' ? 'bg-cogni-blue text-black' : 'bg-gray-800 text-gray-400'}`}
          >
            List
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={`px-3 py-1 rounded text-xs ${viewMode === 'calendar' ? 'bg-cogni-blue text-black' : 'bg-gray-800 text-gray-400'}`}
          >
            Week
          </button>
        </div>
      </div>

      {/* Weekly Summary */}
      {avgMood && (
        <div className="bg-gray-800/50 rounded-lg p-3 flex items-center justify-between">
          <span className="text-gray-400 text-sm">This week's average mood</span>
          <div className="flex items-center gap-2">
            <span className="text-lg">{getMoodEmoji(Math.round(avgMood))}</span>
            <span className="text-white font-medium">{avgMood}/3</span>
          </div>
        </div>
      )}

      {/* New Entry Button/Form */}
      {showNewEntry ? (
        <div className="bg-gray-800/50 rounded-xl p-4 space-y-4">
          <div className="text-sm text-gray-400 mb-2">How are you feeling?</div>
          
          {/* Mood Selection */}
          <div className="flex justify-around">
            {MOOD_OPTIONS.map((mood) => (
              <button
                key={mood.value}
                onClick={() => setNewEntry({ ...newEntry, mood: mood.value })}
                className={`flex flex-col items-center p-3 rounded-xl transition-all ${
                  newEntry.mood === mood.value 
                    ? 'bg-cogni-blue/20 ring-2 ring-cogni-blue scale-110' 
                    : 'hover:bg-gray-700'
                }`}
              >
                <span className="text-3xl mb-1">{mood.emoji}</span>
                <span className="text-xs text-gray-400">{mood.label}</span>
              </button>
            ))}
          </div>

          {/* Activity Tags */}
          <div>
            <div className="text-sm text-gray-400 mb-2">What have you been doing?</div>
            <div className="flex flex-wrap gap-2">
              {ACTIVITY_TAGS.map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-3 py-1 rounded-full text-xs transition-colors ${
                    newEntry.tags.includes(tag)
                      ? 'bg-cogni-teal text-black'
                      : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>

          {/* Note */}
          <textarea
            value={newEntry.note}
            onChange={(e) => setNewEntry({ ...newEntry, note: e.target.value })}
            placeholder="Add a note (optional)..."
            className="w-full bg-gray-900 text-white rounded-lg p-3 border border-gray-700 focus:border-cogni-blue focus:outline-none text-sm resize-none h-20"
          />

          {/* Current State Preview */}
          {currentState && currentState.cognitive_load > 0 && (
            <div className="bg-gray-900/50 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-2">Current cognitive snapshot (will be saved)</div>
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div>
                  <span className="text-gray-500">Load: </span>
                  <span className={getStateColor(currentState.cognitive_load, 'cognitive_load')}>
                    {(currentState.cognitive_load * 100).toFixed(0)}%
                  </span>
                </div>
                <div>
                  <span className="text-gray-500">Heat: </span>
                  <span className={getStateColor(currentState.heat_index, 'heat')}>
                    {(currentState.heat_index * 100).toFixed(0)}%
                  </span>
                </div>
                <div>
                  <span className="text-gray-500">Rage: </span>
                  <span className={getStateColor(currentState.rage_index, 'rage')}>
                    {(currentState.rage_index * 100).toFixed(0)}%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-2">
            <button
              onClick={handleSaveEntry}
              disabled={newEntry.mood === null}
              className="flex-1 bg-cogni-blue hover:bg-cogni-blue/80 disabled:bg-gray-700 disabled:text-gray-500 text-black font-medium py-2 rounded-lg text-sm transition-colors"
            >
              Save Entry
            </button>
            <button
              onClick={() => {
                setShowNewEntry(false)
                setNewEntry({ mood: null, note: '', tags: [], cognitiveSnapshot: null })
              }}
              className="px-4 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      ) : (
        <button
          onClick={() => setShowNewEntry(true)}
          className="w-full bg-gradient-to-r from-cogni-blue/20 to-cogni-teal/20 hover:from-cogni-blue/30 hover:to-cogni-teal/30 border border-cogni-blue/30 text-white py-4 rounded-xl transition-all"
        >
          <span className="text-lg mr-2">+</span> Log how you're feeling
        </button>
      )}

      {/* Entries List */}
      {viewMode === 'list' && manualEntries.length > 0 && (
        <div className="space-y-2">
          {manualEntries.map((entry) => (
            <div key={entry.id} className="bg-gray-800/30 rounded-lg p-3 border border-gray-700/50">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{getMoodEmoji(entry.mood)}</span>
                  <div>
                    <div className="text-xs text-gray-500">{formatDate(entry.timestamp)}</div>
                    {entry.note && <div className="text-sm text-gray-300 mt-1">{entry.note}</div>}
                    {entry.tags.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {entry.tags.map(tag => (
                          <span key={tag} className="text-xs bg-gray-700 text-gray-400 px-2 py-0.5 rounded">
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => handleDeleteEntry(entry.id)}
                  className="text-gray-600 hover:text-red-400 text-sm transition-colors"
                >
                  ✕
                </button>
              </div>
              
              {/* Cognitive Snapshot */}
              {entry.cognitiveSnapshot && (
                <div className="mt-3 pt-3 border-t border-gray-700/50 grid grid-cols-4 gap-2 text-xs">
                  <div>
                    <span className="text-gray-500">Load </span>
                    <span className={getStateColor(entry.cognitiveSnapshot.cognitive_load, 'cognitive_load')}>
                      {(entry.cognitiveSnapshot.cognitive_load * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Stability </span>
                    <span className={getStateColor(entry.cognitiveSnapshot.decision_stability, 'decision_stability')}>
                      {(entry.cognitiveSnapshot.decision_stability * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Heat </span>
                    <span className={getStateColor(entry.cognitiveSnapshot.heat_index || 0, 'heat')}>
                      {((entry.cognitiveSnapshot.heat_index || 0) * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div>
                    <span className="text-gray-500">Rage </span>
                    <span className={getStateColor(entry.cognitiveSnapshot.rage_index || 0, 'rage')}>
                      {((entry.cognitiveSnapshot.rage_index || 0) * 100).toFixed(0)}%
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Week View */}
      {viewMode === 'calendar' && (
        <div className="bg-gray-800/30 rounded-lg p-4">
          <div className="grid grid-cols-7 gap-2 text-center">
            {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
              <div key={i} className="text-xs text-gray-500 pb-2">{day}</div>
            ))}
            {Array.from({ length: 7 }).map((_, i) => {
              const date = new Date()
              date.setDate(date.getDate() - (6 - i))
              const dayStart = new Date(date.setHours(0, 0, 0, 0)).getTime()
              const dayEnd = new Date(date.setHours(23, 59, 59, 999)).getTime()
              const dayEntries = entries.filter(
                e => e.type === 'manual' && e.timestamp >= dayStart && e.timestamp <= dayEnd
              )
              const avgMood = dayEntries.length > 0
                ? Math.round(dayEntries.reduce((sum, e) => sum + e.mood, 0) / dayEntries.length)
                : null

              return (
                <div
                  key={i}
                  className={`aspect-square rounded-lg flex items-center justify-center text-lg ${
                    avgMood !== null ? 'bg-gray-700' : 'bg-gray-800/50'
                  }`}
                >
                  {avgMood !== null ? getMoodEmoji(avgMood) : (
                    <span className="text-gray-600 text-xs">{date.getDate()}</span>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {manualEntries.length === 0 && !showNewEntry && (
        <p className="text-center text-gray-500 text-sm py-4">
          No entries yet. Start tracking how you feel!
        </p>
      )}
    </div>
  )
}

export default BehaviorDiary
