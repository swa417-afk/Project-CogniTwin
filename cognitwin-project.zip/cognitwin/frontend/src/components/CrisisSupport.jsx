import { useState, useEffect } from 'react'

// Pre-installed crisis hotlines
const CRISIS_HOTLINES = [
  { name: "988 Suicide & Crisis Lifeline", number: "988", country: "US", primary: true },
  { name: "Crisis Text Line", number: "741741", country: "US", type: "text", note: "Text HOME" },
  { name: "National Suicide Prevention", number: "1-800-273-8255", country: "US" },
  { name: "Samaritans", number: "116 123", country: "UK" },
  { name: "Kids Help Phone", number: "1-800-668-6868", country: "Canada" },
  { name: "Lifeline", number: "13 11 14", country: "Australia" },
]

function CrisisSupport({ isLocked, onUnlock }) {
  const [contacts, setContacts] = useState([])
  const [showAddForm, setShowAddForm] = useState(false)
  const [newContact, setNewContact] = useState({ name: '', number: '', relationship: '' })
  const [pin, setPin] = useState('')
  const [storedPin, setStoredPin] = useState(null)
  const [showPinSetup, setShowPinSetup] = useState(false)
  const [confirmPin, setConfirmPin] = useState('')

  // Load contacts and PIN from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('cognitwin_crisis_contacts')
    if (saved) setContacts(JSON.parse(saved))
    
    const savedPin = localStorage.getItem('cognitwin_pin')
    if (savedPin) setStoredPin(savedPin)
  }, [])

  // Save contacts to localStorage
  useEffect(() => {
    localStorage.setItem('cognitwin_crisis_contacts', JSON.stringify(contacts))
  }, [contacts])

  const handleAddContact = () => {
    if (newContact.name && newContact.number && contacts.length < 5) {
      setContacts([...contacts, { ...newContact, id: Date.now() }])
      setNewContact({ name: '', number: '', relationship: '' })
      setShowAddForm(false)
    }
  }

  const handleRemoveContact = (id) => {
    setContacts(contacts.filter(c => c.id !== id))
  }

  const handleCall = (number) => {
    window.location.href = `tel:${number.replace(/\s/g, '')}`
  }

  const handleText = (number) => {
    window.location.href = `sms:${number.replace(/\s/g, '')}`
  }

  const handleSetPin = () => {
    if (pin.length >= 4 && pin === confirmPin) {
      localStorage.setItem('cognitwin_pin', pin)
      setStoredPin(pin)
      setShowPinSetup(false)
      setPin('')
      setConfirmPin('')
    }
  }

  const handleUnlock = () => {
    if (pin === storedPin) {
      onUnlock()
      setPin('')
    }
  }

  // PIN Lock Screen
  if (isLocked && storedPin) {
    return (
      <div className="fixed inset-0 bg-cogni-dark z-50 flex items-center justify-center">
        <div className="bg-cogni-card p-8 rounded-2xl border border-gray-700 max-w-sm w-full mx-4">
          <h2 className="text-xl font-bold text-center mb-6 text-white">🔒 CogniTwin Locked</h2>
          <p className="text-gray-400 text-center mb-6 text-sm">Enter PIN to access your data</p>
          
          <input
            type="password"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            placeholder="Enter PIN"
            maxLength={6}
            className="w-full bg-gray-900 text-white text-center text-2xl tracking-widest rounded-lg p-4 border border-gray-700 focus:border-cogni-blue focus:outline-none mb-4"
          />
          
          <button
            onClick={handleUnlock}
            className="w-full bg-cogni-blue hover:bg-cogni-blue/80 text-black font-semibold py-3 rounded-lg transition-colors"
          >
            Unlock
          </button>
          
          {/* Emergency access */}
          <div className="mt-6 pt-6 border-t border-gray-700">
            <p className="text-gray-500 text-xs text-center mb-3">Emergency? Call for help:</p>
            <button
              onClick={() => handleCall('988')}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 rounded-lg transition-colors"
            >
              📞 988 Crisis Line
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Crisis Hotlines */}
      <div className="bg-red-900/20 border border-red-800/50 rounded-xl p-4">
        <h3 className="text-red-400 font-semibold mb-3 flex items-center gap-2">
          <span>🆘</span> Crisis Hotlines (24/7)
        </h3>
        <div className="space-y-2">
          {CRISIS_HOTLINES.slice(0, 3).map((hotline, i) => (
            <div key={i} className="flex items-center justify-between bg-gray-900/50 rounded-lg p-3">
              <div>
                <div className="text-white text-sm font-medium">{hotline.name}</div>
                <div className="text-gray-400 text-xs">{hotline.country} {hotline.note && `• ${hotline.note}`}</div>
              </div>
              <button
                onClick={() => hotline.type === 'text' ? handleText(hotline.number) : handleCall(hotline.number)}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
              >
                {hotline.type === 'text' ? '💬 Text' : '📞'} {hotline.number}
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Personal Crisis Contacts */}
      <div className="bg-gray-900/30 border border-gray-700/50 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-cogni-teal font-semibold flex items-center gap-2">
            <span>👥</span> My Support Network
          </h3>
          <span className="text-gray-500 text-xs">{contacts.length}/5 contacts</span>
        </div>

        {contacts.length === 0 ? (
          <p className="text-gray-500 text-sm mb-3">Add trusted people who can help in a crisis.</p>
        ) : (
          <div className="space-y-2 mb-3">
            {contacts.map((contact) => (
              <div key={contact.id} className="flex items-center justify-between bg-gray-800/50 rounded-lg p-3">
                <div>
                  <div className="text-white text-sm font-medium">{contact.name}</div>
                  <div className="text-gray-400 text-xs">{contact.relationship}</div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleCall(contact.number)}
                    className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-sm transition-colors"
                  >
                    📞 Call
                  </button>
                  <button
                    onClick={() => handleText(contact.number)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-sm transition-colors"
                  >
                    💬
                  </button>
                  <button
                    onClick={() => handleRemoveContact(contact.id)}
                    className="text-gray-500 hover:text-red-400 px-2 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {showAddForm ? (
          <div className="bg-gray-800/50 rounded-lg p-4 space-y-3">
            <input
              type="text"
              value={newContact.name}
              onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
              placeholder="Name"
              className="w-full bg-gray-900 text-white rounded-lg p-2 border border-gray-700 focus:border-cogni-blue focus:outline-none text-sm"
            />
            <input
              type="tel"
              value={newContact.number}
              onChange={(e) => setNewContact({ ...newContact, number: e.target.value })}
              placeholder="Phone number"
              className="w-full bg-gray-900 text-white rounded-lg p-2 border border-gray-700 focus:border-cogni-blue focus:outline-none text-sm"
            />
            <input
              type="text"
              value={newContact.relationship}
              onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
              placeholder="Relationship (e.g., Mom, Therapist, Friend)"
              className="w-full bg-gray-900 text-white rounded-lg p-2 border border-gray-700 focus:border-cogni-blue focus:outline-none text-sm"
            />
            <div className="flex gap-2">
              <button
                onClick={handleAddContact}
                className="flex-1 bg-cogni-teal hover:bg-cogni-teal/80 text-black font-medium py-2 rounded-lg text-sm transition-colors"
              >
                Add Contact
              </button>
              <button
                onClick={() => setShowAddForm(false)}
                className="px-4 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : contacts.length < 5 && (
          <button
            onClick={() => setShowAddForm(true)}
            className="w-full border border-dashed border-gray-600 hover:border-cogni-teal text-gray-400 hover:text-cogni-teal py-3 rounded-lg text-sm transition-colors"
          >
            + Add Trusted Contact
          </button>
        )}
      </div>

      {/* PIN Setup */}
      <div className="bg-gray-900/30 border border-gray-700/50 rounded-xl p-4">
        <h3 className="text-gray-300 font-semibold mb-3 flex items-center gap-2">
          <span>🔐</span> Privacy Lock
        </h3>
        
        {storedPin ? (
          <div className="flex items-center justify-between">
            <span className="text-gray-400 text-sm">PIN protection enabled</span>
            <button
              onClick={() => {
                localStorage.removeItem('cognitwin_pin')
                setStoredPin(null)
              }}
              className="text-red-400 hover:text-red-300 text-sm transition-colors"
            >
              Remove PIN
            </button>
          </div>
        ) : showPinSetup ? (
          <div className="space-y-3">
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              placeholder="Create PIN (4-6 digits)"
              maxLength={6}
              className="w-full bg-gray-900 text-white rounded-lg p-2 border border-gray-700 focus:border-cogni-blue focus:outline-none text-sm"
            />
            <input
              type="password"
              value={confirmPin}
              onChange={(e) => setConfirmPin(e.target.value)}
              placeholder="Confirm PIN"
              maxLength={6}
              className="w-full bg-gray-900 text-white rounded-lg p-2 border border-gray-700 focus:border-cogni-blue focus:outline-none text-sm"
            />
            <div className="flex gap-2">
              <button
                onClick={handleSetPin}
                disabled={pin.length < 4 || pin !== confirmPin}
                className="flex-1 bg-cogni-blue hover:bg-cogni-blue/80 disabled:bg-gray-700 disabled:text-gray-500 text-black font-medium py-2 rounded-lg text-sm transition-colors"
              >
                Set PIN
              </button>
              <button
                onClick={() => {
                  setShowPinSetup(false)
                  setPin('')
                  setConfirmPin('')
                }}
                className="px-4 bg-gray-700 hover:bg-gray-600 text-white rounded-lg text-sm transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowPinSetup(true)}
            className="w-full bg-gray-800 hover:bg-gray-700 text-gray-300 py-2 rounded-lg text-sm transition-colors"
          >
            Set up PIN Lock
          </button>
        )}
      </div>
    </div>
  )
}

export default CrisisSupport
