// frontend/src/components/AgentExplainer.jsx

import { useState } from 'react'

function AgentExplainer({ agentResult, onAcknowledge, onUpdateThreshold }) {
  const [expandedRule, setExpandedRule] = useState(null)
  const [showSettings, setShowSettings] = useState(false)

  if (!agentResult) {
    return (
      <div className="text-gray-500 text-sm text-center py-4">
        Start typing to see agent evaluations...
      </div>
    )
  }

  const { action, evaluations, settings, escalation_count } = agentResult

  return (
    <div className="space-y-4">
      {/* Current Action Banner */}
      {action && (
        <div className={`rounded-xl p-4 border ${getActionStyle(action.action)}`}>
          <div className="flex items-start justify-between">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-lg">{getActionIcon(action.action)}</span>
                <span className="font-semibold text-white">{getActionLabel(action.action)}</span>
              </div>
              <p className="text-sm text-gray-300">{action.payload?.message}</p>
            </div>
            {(action.action === 'show_crisis_resources' || action.action === 'offer_support') && (
              <button
                onClick={onAcknowledge}
                className="text-xs bg-white/20 hover:bg-white/30 px-3 py-1 rounded transition-colors"
              >
                I'm okay
              </button>
            )}
          </div>
          
          {/* WHY Banner - THE KEY DEMO FEATURE */}
          <div className="mt-3 p-3 bg-black/40 rounded-lg border border-white/10">
            <div className="text-xs text-cogni-teal mb-1 font-semibold">🔍 WHY DID THIS TRIGGER?</div>
            <div className="text-sm text-white font-mono">{action.why}</div>
          </div>
        </div>
      )}

      {/* Escalation Warning */}
      {escalation_count > 0 && (
        <div className="flex items-center justify-between bg-orange-500/20 border border-orange-500/50 rounded-lg p-3">
          <span className="text-orange-300 text-sm">
            ⚠️ Escalation level: {escalation_count}/3
          </span>
          <button
            onClick={onAcknowledge}
            className="text-xs bg-orange-500/30 hover:bg-orange-500/50 text-orange-200 px-3 py-1 rounded transition-colors"
          >
            Reset
          </button>
        </div>
      )}

      {/* Rule Evaluations Header */}
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-gray-400">All Rules</h4>
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="text-xs text-cogni-blue hover:text-cogni-teal transition-colors"
        >
          ⚙️ {showSettings ? 'Hide' : 'Edit'} Thresholds
        </button>
      </div>

      {/* Rule Cards */}
      <div className="space-y-2">
        {evaluations?.map((evaluation) => (
          <RuleCard
            key={evaluation.rule_id}
            evaluation={evaluation}
            expanded={expandedRule === evaluation.rule_id}
            onToggle={() => setExpandedRule(
              expandedRule === evaluation.rule_id ? null : evaluation.rule_id
            )}
          />
        ))}
      </div>

      {/* Threshold Settings Panel */}
      {showSettings && settings && (
        <ThresholdSettings
          thresholds={settings.thresholds}
          onUpdate={onUpdateThreshold}
        />
      )}
    </div>
  )
}

function RuleCard({ evaluation, expanded, onToggle }) {
  const { rule_id, rule_name, triggered, conditions_met, conditions_failed, actual_values, thresholds_used, explanation } = evaluation

  return (
    <div
      className={`rounded-lg border transition-all cursor-pointer ${
        triggered
          ? 'bg-gradient-to-r from-red-500/20 to-orange-500/10 border-red-500/50'
          : 'bg-gray-800/30 border-gray-700/50 hover:border-gray-600'
      }`}
      onClick={onToggle}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <div className={`w-3 h-3 rounded-full ${triggered ? 'bg-red-500 animate-pulse' : 'bg-gray-600'}`} />
          <span className="text-sm text-white">{rule_name}</span>
        </div>
        <div className="flex items-center gap-2">
          <span className={`text-xs px-2 py-0.5 rounded font-medium ${
            triggered ? 'bg-red-500/30 text-red-300' : 'bg-gray-700 text-gray-400'
          }`}>
            {triggered ? '⚡ TRIGGERED' : 'waiting'}
          </span>
          <span className="text-gray-500 text-xs">{expanded ? '▲' : '▼'}</span>
        </div>
      </div>

      {/* Expanded Details */}
      {expanded && (
        <div className="px-3 pb-3 border-t border-gray-700/50 pt-3 space-y-3">
          {/* Values vs Thresholds - THE KEY TRANSPARENCY */}
          {actual_values && thresholds_used && (
            <div className="bg-black/30 rounded-lg p-3">
              <div className="text-xs text-gray-400 mb-2">📊 Values vs Thresholds:</div>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(actual_values).map(([key, value]) => {
                  const threshold = thresholds_used[key] || thresholds_used[key.replace('_index', '_high')]
                  const isOver = threshold !== undefined && (
                    key.includes('stability') ? value < threshold : value > threshold
                  )
                  return (
                    <div key={key} className={`text-xs font-mono p-2 rounded ${isOver ? 'bg-red-500/20 text-red-300' : 'bg-gray-800/50 text-gray-400'}`}>
                      <span className="text-gray-500">{key}:</span>{' '}
                      <span className={isOver ? 'text-red-300 font-bold' : 'text-white'}>{typeof value === 'number' ? value.toFixed(2) : value}</span>
                      {threshold !== undefined && (
                        <span className="text-gray-500"> (thresh: {threshold})</span>
                      )}
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* Conditions Met */}
          {conditions_met?.length > 0 && (
            <div>
              <div className="text-xs text-green-400 mb-1">✓ Passed:</div>
              <div className="space-y-1">
                {conditions_met.map((cond, i) => (
                  <div key={i} className="text-xs text-green-300 font-mono bg-green-500/10 px-2 py-1 rounded">
                    {cond}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Conditions Failed */}
          {conditions_failed?.length > 0 && (
            <div>
              <div className="text-xs text-gray-500 mb-1">✗ Not met:</div>
              <div className="space-y-1">
                {conditions_failed.map((cond, i) => (
                  <div key={i} className="text-xs text-gray-500 font-mono bg-gray-800/50 px-2 py-1 rounded">
                    {cond}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Summary */}
          <div className="text-xs text-gray-400 italic border-t border-gray-700/50 pt-2">{explanation}</div>
        </div>
      )}
    </div>
  )
}

function ThresholdSettings({ thresholds, onUpdate }) {
  const [editing, setEditing] = useState(null)
  const [tempValue, setTempValue] = useState('')

  const handleSave = (name) => {
    const value = parseFloat(tempValue)
    if (!isNaN(value) && value >= 0 && value <= 1) {
      onUpdate(name, value)
    }
    setEditing(null)
  }

  const displayThresholds = [
    { key: 'rage_high', label: 'Rage (support)', color: 'text-orange-400' },
    { key: 'rage_crisis', label: 'Rage (crisis)', color: 'text-red-400' },
    { key: 'heat_high', label: 'Heat (calm mode)', color: 'text-yellow-400' },
    { key: 'cognitive_load_high', label: 'Cognitive Load', color: 'text-blue-400' },
    { key: 'stability_low', label: 'Stability (low)', color: 'text-purple-400' },
    { key: 'mood_negative', label: 'Mood (negative)', color: 'text-cyan-400' },
  ]

  return (
    <div className="bg-gray-900/50 rounded-xl p-4 border border-cogni-blue/30">
      <h4 className="text-sm font-semibold text-cogni-blue mb-1">⚙️ Your Thresholds</h4>
      <p className="text-xs text-gray-500 mb-3">Click values to customize when rules trigger.</p>
      
      <div className="grid grid-cols-2 gap-2">
        {displayThresholds.map(({ key, label, color }) => {
          const value = thresholds[key]
          if (value === undefined) return null

          return (
            <div key={key} className="flex items-center justify-between bg-gray-800/50 rounded-lg px-3 py-2">
              <span className={`text-xs ${color}`}>{label}</span>
              {editing === key ? (
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step="0.05"
                    min="0"
                    max="1"
                    value={tempValue}
                    onChange={(e) => setTempValue(e.target.value)}
                    className="w-14 bg-gray-900 text-white text-center rounded px-1 py-0.5 text-xs border border-cogni-blue"
                    autoFocus
                    onKeyDown={(e) => e.key === 'Enter' && handleSave(key)}
                  />
                  <button onClick={() => handleSave(key)} className="text-xs text-green-400">✓</button>
                </div>
              ) : (
                <button
                  onClick={() => { setEditing(key); setTempValue(value.toString()) }}
                  className="text-sm font-mono text-white hover:text-cogni-teal transition-colors"
                >
                  {value}
                </button>
              )}
            </div>
          )
        })}
      </div>
    </div>
  )
}

function getActionIcon(action) {
  const icons = {
    'calm_mode': '🌊',
    'suggest_break': '☕',
    'show_breathing': '🧘',
    'offer_support': '💬',
    'show_crisis_resources': '🆘',
    'alert_contacts': '🚨'
  }
  return icons[action] || '📋'
}

function getActionLabel(action) {
  const labels = {
    'calm_mode': 'Calm Mode Activated',
    'suggest_break': 'Take a Break',
    'show_breathing': 'Breathing Exercise',
    'offer_support': 'Support Available',
    'show_crisis_resources': 'Crisis Resources',
    'alert_contacts': 'Alerting Contacts'
  }
  return labels[action] || action
}

function getActionStyle(action) {
  const styles = {
    'calm_mode': 'bg-blue-500/20 border-blue-500/50',
    'suggest_break': 'bg-yellow-500/20 border-yellow-500/50',
    'show_breathing': 'bg-purple-500/20 border-purple-500/50',
    'offer_support': 'bg-orange-500/20 border-orange-500/50',
    'show_crisis_resources': 'bg-red-500/20 border-red-500/50',
    'alert_contacts': 'bg-red-600/30 border-red-600/50'
  }
  return styles[action] || 'bg-gray-500/20 border-gray-500/50'
}

export default AgentExplainer
