function StateGauge({ label, value, min, max, color, showPlusMinus, description }) {
  // Normalize value to 0-100 for display
  const normalizedValue = ((value - min) / (max - min)) * 100
  const displayValue = showPlusMinus
    ? (value >= 0 ? '+' : '') + value.toFixed(2)
    : (value * 100).toFixed(0) + '%'

  const colorClasses = {
    orange: {
      bar: 'bg-orange-500',
      glow: 'shadow-orange-500/50',
      text: 'text-orange-400'
    },
    blue: {
      bar: 'bg-blue-500',
      glow: 'shadow-blue-500/50',
      text: 'text-blue-400'
    },
    green: {
      bar: 'bg-green-500',
      glow: 'shadow-green-500/50',
      text: 'text-green-400'
    },
    red: {
      bar: 'bg-red-500',
      glow: 'shadow-red-500/50',
      text: 'text-red-400'
    },
    yellow: {
      bar: 'bg-yellow-500',
      glow: 'shadow-yellow-500/50',
      text: 'text-yellow-400'
    },
    crimson: {
      bar: 'bg-rose-600',
      glow: 'shadow-rose-600/50',
      text: 'text-rose-400'
    }
  }

  const colors = colorClasses[color] || colorClasses.blue

  // For mood drift, center the bar
  const isCentered = showPlusMinus
  const barStyle = isCentered
    ? {
        left: value >= 0 ? '50%' : `${50 + (value * 50)}%`,
        width: `${Math.abs(value) * 50}%`
      }
    : {
        left: '0%',
        width: `${normalizedValue}%`
      }

  return (
    <div className="bg-gray-900/50 rounded-xl p-4 border border-gray-700/50">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-gray-300">{label}</span>
        <span className={`text-lg font-bold ${colors.text}`}>
          {displayValue}
        </span>
      </div>
      
      {/* Progress bar */}
      <div className="relative h-3 bg-gray-800 rounded-full overflow-hidden">
        {isCentered && (
          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gray-600" />
        )}
        <div
          className={`absolute top-0 bottom-0 ${colors.bar} rounded-full transition-all duration-300 shadow-lg ${colors.glow}`}
          style={barStyle}
        />
      </div>

      {/* Description */}
      <p className="mt-2 text-xs text-gray-500">{description}</p>
    </div>
  )
}

export default StateGauge
