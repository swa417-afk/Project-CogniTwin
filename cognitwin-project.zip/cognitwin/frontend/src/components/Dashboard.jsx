import StateGauge from './StateGauge'

function Dashboard({ state }) {
  return (
    <div className="space-y-4">
      {/* Primary metrics */}
      <div className="grid grid-cols-2 gap-4">
        <StateGauge
          label="Cognitive Load"
          value={state.cognitive_load}
          min={0}
          max={1}
          color="orange"
          description="Mental effort required"
        />
        <StateGauge
          label="Mood Drift"
          value={state.mood_drift}
          min={-1}
          max={1}
          color="blue"
          showPlusMinus
          description="Change from baseline"
        />
        <StateGauge
          label="Decision Stability"
          value={state.decision_stability}
          min={0}
          max={1}
          color="green"
          description="Consistency in behavior"
        />
        <StateGauge
          label="Risk Volatility"
          value={state.risk_volatility}
          min={0}
          max={1}
          color="red"
          description="Behavioral irregularity"
        />
      </div>

      {/* Heat & Rage indicators */}
      <div className="pt-4 border-t border-gray-700/50">
        <div className="text-xs text-gray-500 mb-3">Emotional Intensity</div>
        <div className="grid grid-cols-2 gap-4">
          <StateGauge
            label="🔥 Heat Index"
            value={state.heat_index || 0}
            min={0}
            max={1}
            color="yellow"
            description="Emotional intensity level"
          />
          <StateGauge
            label="😤 Rage Index"
            value={state.rage_index || 0}
            min={0}
            max={1}
            color="crimson"
            description="Frustration/anger level"
          />
        </div>
      </div>
    </div>
  )
}

export default Dashboard
