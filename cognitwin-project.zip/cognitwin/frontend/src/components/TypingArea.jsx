import { useState, useRef, useCallback, useEffect } from 'react'

function TypingArea({ onSignalBatch, batchIntervalMs = 2000 }) {
  const [text, setText] = useState('')
  const signalsRef = useRef([])
  const keyDownTimesRef = useRef({})
  const lastKeyUpRef = useRef(null)

  // Send batched signals periodically
  useEffect(() => {
    const interval = setInterval(() => {
      if (signalsRef.current.length > 0) {
        onSignalBatch(signalsRef.current, text)
        signalsRef.current = []
      }
    }, batchIntervalMs)

    return () => clearInterval(interval)
  }, [onSignalBatch, batchIntervalMs, text])

  const handleKeyDown = useCallback((e) => {
    const now = performance.now()
    const key = e.key

    // Record keydown time
    keyDownTimesRef.current[key] = now

    // Calculate flight time (time since last keyup)
    const flightMs = lastKeyUpRef.current ? now - lastKeyUpRef.current : null

    signalsRef.current.push({
      timestamp: Date.now() / 1000,
      key: key,
      event_type: 'keydown',
      dwell_ms: null,
      flight_ms: flightMs
    })
  }, [])

  const handleKeyUp = useCallback((e) => {
    const now = performance.now()
    const key = e.key

    // Calculate dwell time
    const keyDownTime = keyDownTimesRef.current[key]
    const dwellMs = keyDownTime ? now - keyDownTime : null

    // Record keyup time for flight calculation
    lastKeyUpRef.current = now

    // Clean up
    delete keyDownTimesRef.current[key]

    signalsRef.current.push({
      timestamp: Date.now() / 1000,
      key: key,
      event_type: 'keyup',
      dwell_ms: dwellMs,
      flight_ms: null
    })
  }, [])

  const handleChange = (e) => {
    setText(e.target.value)
  }

  return (
    <div>
      <textarea
        value={text}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onKeyUp={handleKeyUp}
        placeholder="Start typing to see your cognitive state update in real-time..."
        className="w-full h-48 bg-gray-900/70 text-gray-100 rounded-lg p-4 border border-gray-700 focus:border-cogni-blue focus:outline-none focus:ring-1 focus:ring-cogni-blue/50 resize-none font-mono text-sm placeholder-gray-600 transition-colors"
      />
      <div className="mt-2 flex justify-between text-xs text-gray-500">
        <span>{text.length} characters</span>
        <span>Signals batched every {batchIntervalMs / 1000}s</span>
      </div>
    </div>
  )
}

export default TypingArea
