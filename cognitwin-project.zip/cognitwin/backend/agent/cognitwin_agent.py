# backend/agent/cognitwin_agent.py

"""
CogniTwin Agent - Autonomous AI agent for cognitive state monitoring and intervention.

The agent:
1. Monitors behavioral patterns over time
2. Detects stress/crisis through multiple signal alignment
3. Uses Claude API for reasoning about user state
4. Takes autonomous actions (alerts, UI adjustments, insights)
"""

import os
import json
import httpx
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, asdict
from enum import Enum

# Claude API config
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL = "claude-sonnet-4-20250514"


class StressLevel(Enum):
    CALM = "calm"
    MILD = "mild"
    ELEVATED = "elevated"
    HIGH = "high"
    CRISIS = "crisis"


class AgentAction(Enum):
    NONE = "none"
    LOG_INSIGHT = "log_insight"
    ADJUST_UI_CALM = "adjust_ui_calm"
    SUGGEST_BREAK = "suggest_break"
    OFFER_SUPPORT = "offer_support"
    ALERT_CONTACTS = "alert_contacts"
    EMERGENCY_RESOURCES = "emergency_resources"


@dataclass
class BehaviorSignal:
    """A single behavioral observation."""
    timestamp: datetime
    signal_type: str  # keystroke, text, interaction
    metrics: Dict[str, float]
    raw_indicators: Dict[str, Any]


@dataclass
class PatternAnalysis:
    """Analysis of behavioral patterns over time."""
    stress_level: StressLevel
    confidence: float
    primary_indicators: List[str]
    trend: str  # improving, stable, worsening
    reasoning: str
    recommended_action: AgentAction


@dataclass
class AgentState:
    """Current state of the agent for a user session."""
    session_id: str
    signal_history: List[BehaviorSignal]
    last_analysis: Optional[PatternAnalysis]
    last_action_time: Optional[datetime]
    action_cooldown_minutes: int = 5
    escalation_level: int = 0  # 0-3, increases with sustained distress


class StressSignalDetector:
    """Detects stress signals from raw behavioral data."""
    
    # Thresholds for stress indicators
    THRESHOLDS = {
        "high_deletion_rate": 0.15,      # >15% keystrokes are deletions
        "rapid_revision": 3,              # >3 revisions in 30 seconds
        "elevated_heat": 0.5,             # heat_index > 0.5
        "elevated_rage": 0.4,             # rage_index > 0.4
        "high_cognitive_load": 0.7,       # cognitive_load > 0.7
        "negative_mood_drift": -0.3,      # mood_drift < -0.3
        "low_stability": 0.3,             # decision_stability < 0.3
        "high_volatility": 0.6,           # risk_volatility > 0.6
        "caps_shouting": 0.3,             # caps_ratio > 0.3
        "error_burst_threshold": 2,       # >2 error bursts
        "typing_acceleration": 0.3,       # speed increased >30%
        "rhythm_chaos": 0.5,              # rhythm_chaos > 0.5
    }
    
    def detect_signals(self, cognitive_state: Dict, features: Dict) -> Dict[str, bool]:
        """Detect which stress signals are present."""
        signals = {
            "high_deletion_rate": features.get("error_rate", 0) > self.THRESHOLDS["high_deletion_rate"],
            "elevated_heat": cognitive_state.get("heat_index", 0) > self.THRESHOLDS["elevated_heat"],
            "elevated_rage": cognitive_state.get("rage_index", 0) > self.THRESHOLDS["elevated_rage"],
            "high_cognitive_load": cognitive_state.get("cognitive_load", 0) > self.THRESHOLDS["high_cognitive_load"],
            "negative_mood": cognitive_state.get("mood_drift", 0) < self.THRESHOLDS["negative_mood_drift"],
            "low_stability": cognitive_state.get("decision_stability", 1) < self.THRESHOLDS["low_stability"],
            "high_volatility": cognitive_state.get("risk_volatility", 0) > self.THRESHOLDS["high_volatility"],
            "caps_shouting": features.get("caps_ratio", 0) > self.THRESHOLDS["caps_shouting"],
            "error_bursts": features.get("error_burst_count", 0) > self.THRESHOLDS["error_burst_threshold"],
            "typing_acceleration": features.get("speed_acceleration", 0) > self.THRESHOLDS["typing_acceleration"],
            "rhythm_chaos": features.get("rhythm_chaos", 0) > self.THRESHOLDS["rhythm_chaos"],
        }
        return signals
    
    def count_active_signals(self, signals: Dict[str, bool]) -> int:
        """Count how many stress signals are active."""
        return sum(1 for v in signals.values() if v)
    
    def estimate_stress_level(self, signals: Dict[str, bool]) -> StressLevel:
        """Estimate stress level based on signal count and severity."""
        count = self.count_active_signals(signals)
        
        # Check for crisis indicators (rage + multiple other signals)
        if signals.get("elevated_rage") and count >= 4:
            return StressLevel.CRISIS
        if count >= 6:
            return StressLevel.CRISIS
        if count >= 4:
            return StressLevel.HIGH
        if count >= 2:
            return StressLevel.ELEVATED
        if count >= 1:
            return StressLevel.MILD
        return StressLevel.CALM


class CogniTwinAgent:
    """
    Autonomous AI agent for monitoring cognitive state and taking action.
    
    The agent observes behavioral patterns, reasons about user state using Claude,
    and takes appropriate interventions when stress/crisis is detected.
    """
    
    def __init__(self, session_id: str):
        self.state = AgentState(
            session_id=session_id,
            signal_history=[],
            last_analysis=None,
            last_action_time=None
        )
        self.detector = StressSignalDetector()
        self.insights_log: List[Dict] = []
    
    def observe(self, cognitive_state: Dict, features: Dict, text_snapshot: str = "") -> BehaviorSignal:
        """Record a new behavioral observation."""
        signal = BehaviorSignal(
            timestamp=datetime.utcnow(),
            signal_type="composite",
            metrics={
                "cognitive_load": cognitive_state.get("cognitive_load", 0),
                "mood_drift": cognitive_state.get("mood_drift", 0),
                "decision_stability": cognitive_state.get("decision_stability", 1),
                "risk_volatility": cognitive_state.get("risk_volatility", 0),
                "heat_index": cognitive_state.get("heat_index", 0),
                "rage_index": cognitive_state.get("rage_index", 0),
            },
            raw_indicators={
                "error_rate": features.get("error_rate", 0),
                "caps_ratio": features.get("caps_ratio", 0),
                "error_burst_count": features.get("error_burst_count", 0),
                "speed_acceleration": features.get("speed_acceleration", 0),
                "rhythm_chaos": features.get("rhythm_chaos", 0),
                "text_length": len(text_snapshot),
            }
        )
        
        # Keep last 50 signals (rolling window)
        self.state.signal_history.append(signal)
        if len(self.state.signal_history) > 50:
            self.state.signal_history = self.state.signal_history[-50:]
        
        return signal
    
    def analyze_patterns(self, cognitive_state: Dict, features: Dict) -> PatternAnalysis:
        """Analyze behavioral patterns and determine stress level."""
        # Detect current signals
        signals = self.detector.detect_signals(cognitive_state, features)
        active_signals = [k for k, v in signals.items() if v]
        stress_level = self.detector.estimate_stress_level(signals)
        
        # Analyze trend (compare to recent history)
        trend = self._analyze_trend()
        
        # Determine confidence based on signal alignment
        signal_count = len(active_signals)
        confidence = min(0.95, 0.5 + (signal_count * 0.1))
        
        # Determine recommended action
        action = self._determine_action(stress_level, trend)
        
        # Generate reasoning
        reasoning = self._generate_reasoning(stress_level, active_signals, trend)
        
        analysis = PatternAnalysis(
            stress_level=stress_level,
            confidence=confidence,
            primary_indicators=active_signals[:5],  # Top 5
            trend=trend,
            reasoning=reasoning,
            recommended_action=action
        )
        
        self.state.last_analysis = analysis
        return analysis
    
    def _analyze_trend(self) -> str:
        """Analyze if stress is improving, stable, or worsening."""
        history = self.state.signal_history
        if len(history) < 5:
            return "stable"
        
        # Compare recent (last 5) vs older (5-10 back)
        recent = history[-5:]
        older = history[-10:-5] if len(history) >= 10 else history[:5]
        
        recent_avg_load = sum(s.metrics.get("cognitive_load", 0) for s in recent) / len(recent)
        older_avg_load = sum(s.metrics.get("cognitive_load", 0) for s in older) / len(older)
        
        recent_avg_heat = sum(s.metrics.get("heat_index", 0) for s in recent) / len(recent)
        older_avg_heat = sum(s.metrics.get("heat_index", 0) for s in older) / len(older)
        
        # Combined score
        recent_stress = recent_avg_load + recent_avg_heat
        older_stress = older_avg_load + older_avg_heat
        
        diff = recent_stress - older_stress
        if diff > 0.2:
            return "worsening"
        elif diff < -0.2:
            return "improving"
        return "stable"
    
    def _determine_action(self, stress_level: StressLevel, trend: str) -> AgentAction:
        """Determine what action the agent should take."""
        # Check cooldown
        if self.state.last_action_time:
            cooldown = timedelta(minutes=self.state.action_cooldown_minutes)
            if datetime.utcnow() - self.state.last_action_time < cooldown:
                # Still in cooldown, only act on crisis
                if stress_level != StressLevel.CRISIS:
                    return AgentAction.LOG_INSIGHT
        
        # Map stress level to action
        if stress_level == StressLevel.CRISIS:
            if self.state.escalation_level >= 2:
                return AgentAction.ALERT_CONTACTS
            return AgentAction.EMERGENCY_RESOURCES
        
        if stress_level == StressLevel.HIGH:
            if trend == "worsening":
                self.state.escalation_level = min(3, self.state.escalation_level + 1)
                return AgentAction.OFFER_SUPPORT
            return AgentAction.SUGGEST_BREAK
        
        if stress_level == StressLevel.ELEVATED:
            return AgentAction.ADJUST_UI_CALM
        
        if stress_level == StressLevel.MILD:
            # Reset escalation if improving
            if trend == "improving":
                self.state.escalation_level = max(0, self.state.escalation_level - 1)
            return AgentAction.LOG_INSIGHT
        
        # Calm - reset escalation
        self.state.escalation_level = 0
        return AgentAction.NONE
    
    def _generate_reasoning(self, stress_level: StressLevel, indicators: List[str], trend: str) -> str:
        """Generate human-readable reasoning for the analysis."""
        if not indicators:
            return "No significant stress indicators detected. User appears calm."
        
        indicator_descriptions = {
            "high_deletion_rate": "frequent text deletions",
            "elevated_heat": "elevated emotional intensity",
            "elevated_rage": "signs of frustration or anger",
            "high_cognitive_load": "high mental effort",
            "negative_mood": "negative mood shift",
            "low_stability": "inconsistent behavior patterns",
            "high_volatility": "erratic behavioral signals",
            "caps_shouting": "use of caps (possible shouting)",
            "error_bursts": "clusters of typing errors",
            "typing_acceleration": "accelerated typing speed",
            "rhythm_chaos": "irregular typing rhythm",
        }
        
        described = [indicator_descriptions.get(i, i) for i in indicators[:3]]
        indicator_text = ", ".join(described)
        
        trend_text = {
            "improving": "Stress levels appear to be decreasing.",
            "stable": "Stress levels are holding steady.",
            "worsening": "Stress levels are increasing over time."
        }
        
        return f"Detected {stress_level.value} stress based on: {indicator_text}. {trend_text.get(trend, '')}"
    
    async def reason_with_llm(self, cognitive_state: Dict, features: Dict, text_hint: str = "") -> Dict:
        """
        Use Claude to reason about the user's cognitive state and recommend action.
        
        This provides deeper, contextual analysis beyond rule-based detection.
        """
        if not ANTHROPIC_API_KEY:
            return {"error": "No API key configured", "fallback": True}
        
        # Build context for Claude
        recent_signals = self.state.signal_history[-10:] if self.state.signal_history else []
        signal_summary = [
            {
                "time_ago_seconds": (datetime.utcnow() - s.timestamp).total_seconds(),
                "cognitive_load": s.metrics.get("cognitive_load"),
                "heat": s.metrics.get("heat_index"),
                "rage": s.metrics.get("rage_index"),
                "mood": s.metrics.get("mood_drift"),
            }
            for s in recent_signals
        ]
        
        prompt = f"""You are CogniTwin, an AI agent monitoring a user's cognitive and emotional state through their typing behavior.

## Current State
- Cognitive Load: {cognitive_state.get('cognitive_load', 0):.2f} (0-1, higher = more mental effort)
- Mood Drift: {cognitive_state.get('mood_drift', 0):.2f} (-1 to 1, negative = worse mood)
- Decision Stability: {cognitive_state.get('decision_stability', 1):.2f} (0-1, lower = more erratic)
- Risk Volatility: {cognitive_state.get('risk_volatility', 0):.2f} (0-1, higher = more volatile)
- Heat Index: {cognitive_state.get('heat_index', 0):.2f} (0-1, emotional intensity)
- Rage Index: {cognitive_state.get('rage_index', 0):.2f} (0-1, frustration/anger)

## Behavioral Signals
- Error Rate (deletions): {features.get('error_rate', 0):.2%}
- Caps Ratio: {features.get('caps_ratio', 0):.2%}
- Error Bursts: {features.get('error_burst_count', 0)}
- Typing Speed Change: {features.get('speed_acceleration', 0):.2%}
- Rhythm Chaos: {features.get('rhythm_chaos', 0):.2f}

## Recent History (last {len(signal_summary)} observations)
{json.dumps(signal_summary, indent=2)}

## Your Task
1. Assess the user's current stress/emotional state
2. Identify if this is a crisis situation requiring intervention
3. Recommend ONE action from: [none, log_insight, adjust_ui_calm, suggest_break, offer_support, alert_contacts, emergency_resources]
4. Provide a brief, empathetic message for the user (if action needed)

Respond in JSON format:
{{
  "stress_assessment": "calm|mild|elevated|high|crisis",
  "confidence": 0.0-1.0,
  "reasoning": "Brief explanation",
  "recommended_action": "action_name",
  "user_message": "Empathetic message for user (or null if no action)",
  "is_crisis": true/false
}}"""

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    "https://api.anthropic.com/v1/messages",
                    headers={
                        "x-api-key": ANTHROPIC_API_KEY,
                        "content-type": "application/json",
                        "anthropic-version": "2023-06-01"
                    },
                    json={
                        "model": CLAUDE_MODEL,
                        "max_tokens": 500,
                        "messages": [{"role": "user", "content": prompt}]
                    },
                    timeout=10.0
                )
                
                if response.status_code == 200:
                    data = response.json()
                    content = data.get("content", [{}])[0].get("text", "{}")
                    # Parse JSON from response
                    try:
                        return json.loads(content)
                    except json.JSONDecodeError:
                        return {"error": "Failed to parse LLM response", "raw": content}
                else:
                    return {"error": f"API error: {response.status_code}"}
        except Exception as e:
            return {"error": str(e)}
    
    def execute_action(self, action: AgentAction, analysis: PatternAnalysis) -> Dict:
        """Execute the recommended action and return result."""
        self.state.last_action_time = datetime.utcnow()
        
        result = {
            "action": action.value,
            "executed_at": datetime.utcnow().isoformat(),
            "stress_level": analysis.stress_level.value,
            "success": True,
            "payload": {}
        }
        
        if action == AgentAction.NONE:
            result["payload"] = {"message": None}
        
        elif action == AgentAction.LOG_INSIGHT:
            insight = {
                "timestamp": datetime.utcnow().isoformat(),
                "stress_level": analysis.stress_level.value,
                "indicators": analysis.primary_indicators,
                "reasoning": analysis.reasoning
            }
            self.insights_log.append(insight)
            result["payload"] = {"insight_logged": True, "insight": insight}
        
        elif action == AgentAction.ADJUST_UI_CALM:
            result["payload"] = {
                "ui_mode": "calm",
                "changes": [
                    "reduce_animations",
                    "softer_colors",
                    "slower_transitions",
                    "hide_non_essential"
                ],
                "message": "I've adjusted the interface to be gentler. Take your time."
            }
        
        elif action == AgentAction.SUGGEST_BREAK:
            result["payload"] = {
                "suggestion": "break",
                "message": "You seem to be working hard. A short break might help you recharge.",
                "options": ["5 min break", "Breathing exercise", "Continue working"]
            }
        
        elif action == AgentAction.OFFER_SUPPORT:
            result["payload"] = {
                "support_type": "check_in",
                "message": "I notice you might be feeling stressed. Would you like to talk about it, or would some support resources help?",
                "options": ["I'm okay", "Show me coping techniques", "Connect me with support"]
            }
        
        elif action == AgentAction.EMERGENCY_RESOURCES:
            result["payload"] = {
                "alert_level": "high",
                "message": "I'm here for you. If you're going through a difficult time, help is available.",
                "resources": [
                    {"name": "988 Suicide & Crisis Lifeline", "number": "988"},
                    {"name": "Crisis Text Line", "number": "741741", "note": "Text HOME"}
                ],
                "show_crisis_support": True
            }
        
        elif action == AgentAction.ALERT_CONTACTS:
            result["payload"] = {
                "alert_level": "critical",
                "message": "I'm concerned about you. With your permission, I can reach out to your support contacts.",
                "request_permission": True,
                "contacts_to_alert": "user_defined"  # Would be populated from user's crisis contacts
            }
        
        return result
    
    def get_state_summary(self) -> Dict:
        """Get a summary of the agent's current state."""
        return {
            "session_id": self.state.session_id,
            "observations_count": len(self.state.signal_history),
            "escalation_level": self.state.escalation_level,
            "last_analysis": asdict(self.state.last_analysis) if self.state.last_analysis else None,
            "insights_logged": len(self.insights_log),
            "last_action_time": self.state.last_action_time.isoformat() if self.state.last_action_time else None
        }


# Singleton agent instances per session
_agents: Dict[str, CogniTwinAgent] = {}


def get_agent(session_id: str) -> CogniTwinAgent:
    """Get or create an agent for a session."""
    if session_id not in _agents:
        _agents[session_id] = CogniTwinAgent(session_id)
    return _agents[session_id]


async def process_with_agent(
    session_id: str,
    cognitive_state: Dict,
    features: Dict,
    text_snapshot: str = "",
    use_llm: bool = False
) -> Dict:
    """
    Main entry point: process new data through the agent.
    
    Returns the agent's analysis and any actions taken.
    """
    agent = get_agent(session_id)
    
    # Observe new signal
    agent.observe(cognitive_state, features, text_snapshot)
    
    # Analyze patterns
    analysis = agent.analyze_patterns(cognitive_state, features)
    
    # Optionally use LLM for deeper reasoning
    llm_analysis = None
    if use_llm and analysis.stress_level in [StressLevel.HIGH, StressLevel.CRISIS]:
        llm_analysis = await agent.reason_with_llm(cognitive_state, features, text_snapshot)
    
    # Execute recommended action
    action_result = agent.execute_action(analysis.recommended_action, analysis)
    
    return {
        "analysis": asdict(analysis),
        "action": action_result,
        "llm_analysis": llm_analysis,
        "agent_state": agent.get_state_summary()
    }
