# backend/agent/rule_engine.py

"""
CogniTwin Rule Engine - Transparent, Explainable, User-Controlled

Architecture:
  User Behavior → Signal Capture → Pattern Detection → Rule Engine → Actions
                    (local)          (formulas)         (if/then)    (on-device)

Every action includes a full explanation:
  "WHY did this trigger?"
  → "rage=0.85, heat=0.73 exceeded your threshold of 0.8/0.7"
"""

from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Callable
from datetime import datetime, timedelta
from enum import Enum


class ActionType(Enum):
    NONE = "none"
    LOG_PATTERN = "log_pattern"
    CALM_MODE = "calm_mode"
    SUGGEST_BREAK = "suggest_break"
    SHOW_BREATHING = "show_breathing"
    OFFER_SUPPORT = "offer_support"
    SHOW_CRISIS_RESOURCES = "show_crisis_resources"
    ALERT_CONTACTS = "alert_contacts"


@dataclass
class Threshold:
    name: str
    value: float
    min_value: float
    max_value: float
    description: str


@dataclass
class RuleExplanation:
    """Full transparency on why a rule did/didn't trigger."""
    rule_id: str
    rule_name: str
    triggered: bool
    conditions_met: List[str]
    conditions_failed: List[str]
    actual_values: Dict[str, float]
    thresholds_used: Dict[str, float]
    explanation: str  # Human-readable summary


@dataclass
class ActionResult:
    action: ActionType
    triggered_by: RuleExplanation
    timestamp: datetime
    payload: Dict
    user_message: Optional[str]


class UserSettings:
    """User-configurable thresholds."""
    
    DEFAULTS = {
        "rage_high": 0.7,
        "rage_crisis": 0.85,
        "heat_high": 0.6,
        "heat_crisis": 0.8,
        "cognitive_load_high": 0.7,
        "stability_low": 0.3,
        "volatility_high": 0.6,
        "mood_negative": -0.4,
        "error_rate_high": 0.2,
        "sustained_minutes": 5,
        "escalation_count": 3,
    }
    
    def __init__(self):
        self.thresholds = dict(self.DEFAULTS)
        self.disabled_rules: List[str] = []
        self.contact_alert_enabled = True
    
    def get(self, name: str) -> float:
        return self.thresholds.get(name, 0.0)
    
    def set(self, name: str, value: float) -> bool:
        if name in self.thresholds:
            self.thresholds[name] = value
            return True
        return False
    
    def to_dict(self):
        return {
            "thresholds": self.thresholds,
            "disabled_rules": self.disabled_rules,
            "contact_alert_enabled": self.contact_alert_enabled
        }


class RuleEngine:
    """
    Deterministic, transparent rule engine.
    
    Every decision shows:
    - Actual values vs thresholds
    - Which conditions passed/failed
    - Full explanation string
    """
    
    def __init__(self, settings: Optional[UserSettings] = None):
        self.settings = settings or UserSettings()
        self.action_history: List[Dict] = []
        self.last_action_times: Dict[str, datetime] = {}
        self.escalation_count = 0
        self.stress_start_time: Optional[datetime] = None
    
    def evaluate(self, state: Dict, features: Dict) -> Dict:
        """
        Evaluate all rules against current state.
        
        Returns full transparency report.
        """
        evaluations = []
        triggered_action = None
        
        # Rule 1: Calm Mode
        eval1 = self._eval_calm_mode(state)
        evaluations.append(eval1)
        if eval1["triggered"] and not triggered_action:
            if not self._in_cooldown("calm_mode", 10):
                triggered_action = self._make_action(ActionType.CALM_MODE, eval1)
        
        # Rule 2: Suggest Break
        eval2 = self._eval_suggest_break(state)
        evaluations.append(eval2)
        if eval2["triggered"] and not triggered_action:
            if not self._in_cooldown("suggest_break", 15):
                triggered_action = self._make_action(ActionType.SUGGEST_BREAK, eval2)
        
        # Rule 3: Breathing Exercise
        eval3 = self._eval_breathing(state)
        evaluations.append(eval3)
        if eval3["triggered"] and not triggered_action:
            if not self._in_cooldown("breathing", 20):
                triggered_action = self._make_action(ActionType.SHOW_BREATHING, eval3)
        
        # Rule 4: Offer Support
        eval4 = self._eval_offer_support(state)
        evaluations.append(eval4)
        if eval4["triggered"] and not triggered_action:
            if not self._in_cooldown("offer_support", 30):
                triggered_action = self._make_action(ActionType.OFFER_SUPPORT, eval4)
        
        # Rule 5: Crisis Resources (high priority)
        eval5 = self._eval_crisis(state)
        evaluations.append(eval5)
        if eval5["triggered"]:
            self.escalation_count += 1
            if not self._in_cooldown("crisis", 5):
                triggered_action = self._make_action(ActionType.SHOW_CRISIS_RESOURCES, eval5)
        
        # Rule 6: Alert Contacts (highest severity)
        eval6 = self._eval_alert_contacts()
        evaluations.append(eval6)
        if eval6["triggered"]:
            if not self._in_cooldown("alert_contacts", 60):
                triggered_action = self._make_action(ActionType.ALERT_CONTACTS, eval6)
        
        # Log action
        if triggered_action:
            self.action_history.append(triggered_action)
        
        return {
            "action": triggered_action,
            "evaluations": evaluations,
            "escalation_count": self.escalation_count,
            "settings": self.settings.to_dict()
        }
    
    def _eval_calm_mode(self, state: Dict) -> Dict:
        """IF heat > threshold OR load > threshold THEN calm_mode"""
        heat = state.get("heat_index", 0)
        load = state.get("cognitive_load", 0)
        heat_thresh = self.settings.get("heat_high")
        load_thresh = self.settings.get("cognitive_load_high")
        
        heat_met = heat > heat_thresh
        load_met = load > load_thresh
        triggered = heat_met or load_met
        
        met = []
        failed = []
        
        if heat_met:
            met.append(f"heat_index={heat:.2f} > {heat_thresh}")
        else:
            failed.append(f"heat_index={heat:.2f} ≤ {heat_thresh}")
        
        if load_met:
            met.append(f"cognitive_load={load:.2f} > {load_thresh}")
        else:
            failed.append(f"cognitive_load={load:.2f} ≤ {load_thresh}")
        
        return {
            "rule_id": "calm_mode",
            "rule_name": "Activate Calm Mode",
            "triggered": triggered,
            "conditions_met": met,
            "conditions_failed": failed,
            "actual_values": {"heat_index": heat, "cognitive_load": load},
            "thresholds_used": {"heat_high": heat_thresh, "cognitive_load_high": load_thresh},
            "explanation": f"{'TRIGGERED' if triggered else 'Not triggered'}: heat={heat:.2f} (threshold={heat_thresh}), load={load:.2f} (threshold={load_thresh})"
        }
    
    def _eval_suggest_break(self, state: Dict) -> Dict:
        """IF cognitive_load > threshold AND sustained > 3 min THEN suggest_break"""
        load = state.get("cognitive_load", 0)
        load_thresh = self.settings.get("cognitive_load_high")
        
        load_met = load > load_thresh
        
        # Track sustained stress
        if load_met:
            if self.stress_start_time is None:
                self.stress_start_time = datetime.utcnow()
            sustained_sec = (datetime.utcnow() - self.stress_start_time).total_seconds()
            sustained = sustained_sec > 180
        else:
            self.stress_start_time = None
            sustained_sec = 0
            sustained = False
        
        triggered = load_met and sustained
        
        met = []
        failed = []
        
        if load_met:
            met.append(f"cognitive_load={load:.2f} > {load_thresh}")
        else:
            failed.append(f"cognitive_load={load:.2f} ≤ {load_thresh}")
        
        if sustained:
            met.append(f"sustained for {sustained_sec:.0f}s > 180s")
        else:
            failed.append(f"sustained for {sustained_sec:.0f}s ≤ 180s")
        
        return {
            "rule_id": "suggest_break",
            "rule_name": "Suggest Break",
            "triggered": triggered,
            "conditions_met": met,
            "conditions_failed": failed,
            "actual_values": {"cognitive_load": load, "sustained_seconds": sustained_sec},
            "thresholds_used": {"cognitive_load_high": load_thresh, "sustained_seconds": 180},
            "explanation": f"{'TRIGGERED' if triggered else 'Not triggered'}: load={load:.2f}, sustained={sustained_sec:.0f}s"
        }
    
    def _eval_breathing(self, state: Dict) -> Dict:
        """IF heat > thresh AND rage > 0.4 AND stability < thresh THEN breathing"""
        heat = state.get("heat_index", 0)
        rage = state.get("rage_index", 0)
        stability = state.get("decision_stability", 1)
        
        heat_thresh = self.settings.get("heat_high")
        stability_thresh = self.settings.get("stability_low")
        
        heat_met = heat > heat_thresh
        rage_met = rage > 0.4
        stability_met = stability < stability_thresh
        
        triggered = heat_met and rage_met and stability_met
        
        met = []
        failed = []
        
        if heat_met:
            met.append(f"heat={heat:.2f} > {heat_thresh}")
        else:
            failed.append(f"heat={heat:.2f} ≤ {heat_thresh}")
        
        if rage_met:
            met.append(f"rage={rage:.2f} > 0.4")
        else:
            failed.append(f"rage={rage:.2f} ≤ 0.4")
        
        if stability_met:
            met.append(f"stability={stability:.2f} < {stability_thresh}")
        else:
            failed.append(f"stability={stability:.2f} ≥ {stability_thresh}")
        
        return {
            "rule_id": "breathing",
            "rule_name": "Offer Breathing Exercise",
            "triggered": triggered,
            "conditions_met": met,
            "conditions_failed": failed,
            "actual_values": {"heat_index": heat, "rage_index": rage, "decision_stability": stability},
            "thresholds_used": {"heat_high": heat_thresh, "rage": 0.4, "stability_low": stability_thresh},
            "explanation": f"{'TRIGGERED' if triggered else 'Not triggered'}: heat={heat:.2f}, rage={rage:.2f}, stability={stability:.2f}"
        }
    
    def _eval_offer_support(self, state: Dict) -> Dict:
        """IF rage > thresh OR (heat > thresh AND mood < thresh) THEN offer_support"""
        rage = state.get("rage_index", 0)
        heat = state.get("heat_index", 0)
        mood = state.get("mood_drift", 0)
        
        rage_thresh = self.settings.get("rage_high")
        heat_thresh = self.settings.get("heat_high")
        mood_thresh = self.settings.get("mood_negative")
        
        rage_met = rage > rage_thresh
        heat_mood_met = heat > heat_thresh and mood < mood_thresh
        
        triggered = rage_met or heat_mood_met
        
        met = []
        failed = []
        
        if rage_met:
            met.append(f"rage={rage:.2f} > {rage_thresh}")
        else:
            failed.append(f"rage={rage:.2f} ≤ {rage_thresh}")
        
        if heat_mood_met:
            met.append(f"heat={heat:.2f} > {heat_thresh} AND mood={mood:.2f} < {mood_thresh}")
        else:
            failed.append(f"heat+mood combo not met")
        
        return {
            "rule_id": "offer_support",
            "rule_name": "Offer Support",
            "triggered": triggered,
            "conditions_met": met,
            "conditions_failed": failed,
            "actual_values": {"rage_index": rage, "heat_index": heat, "mood_drift": mood},
            "thresholds_used": {"rage_high": rage_thresh, "heat_high": heat_thresh, "mood_negative": mood_thresh},
            "explanation": f"{'TRIGGERED' if triggered else 'Not triggered'}: rage={rage:.2f} (thresh={rage_thresh})"
        }
    
    def _eval_crisis(self, state: Dict) -> Dict:
        """IF rage > crisis_thresh OR (heat > crisis_thresh AND mood < -0.5) THEN crisis"""
        rage = state.get("rage_index", 0)
        heat = state.get("heat_index", 0)
        mood = state.get("mood_drift", 0)
        
        rage_crisis = self.settings.get("rage_crisis")
        heat_crisis = self.settings.get("heat_crisis")
        
        rage_met = rage > rage_crisis
        heat_mood_met = heat > heat_crisis and mood < -0.5
        
        triggered = rage_met or heat_mood_met
        
        met = []
        failed = []
        
        if rage_met:
            met.append(f"⚠️ rage={rage:.2f} > CRISIS threshold {rage_crisis}")
        else:
            failed.append(f"rage={rage:.2f} ≤ {rage_crisis}")
        
        if heat_mood_met:
            met.append(f"⚠️ heat={heat:.2f} > {heat_crisis} AND mood={mood:.2f} < -0.5")
        else:
            failed.append(f"heat+mood crisis combo not met")
        
        return {
            "rule_id": "crisis",
            "rule_name": "Show Crisis Resources",
            "triggered": triggered,
            "conditions_met": met,
            "conditions_failed": failed,
            "actual_values": {"rage_index": rage, "heat_index": heat, "mood_drift": mood},
            "thresholds_used": {"rage_crisis": rage_crisis, "heat_crisis": heat_crisis},
            "explanation": f"{'⚠️ CRISIS TRIGGERED' if triggered else 'No crisis'}: rage={rage:.2f}, heat={heat:.2f}, mood={mood:.2f}"
        }
    
    def _eval_alert_contacts(self) -> Dict:
        """IF escalation_count >= threshold AND contacts_enabled THEN alert"""
        thresh = int(self.settings.get("escalation_count"))
        enabled = self.settings.contact_alert_enabled
        
        count_met = self.escalation_count >= thresh
        triggered = count_met and enabled
        
        met = []
        failed = []
        
        if count_met:
            met.append(f"🚨 escalation_count={self.escalation_count} >= {thresh}")
        else:
            failed.append(f"escalation_count={self.escalation_count} < {thresh}")
        
        if enabled:
            met.append("contact_alerts=enabled")
        else:
            failed.append("contact_alerts=disabled")
        
        return {
            "rule_id": "alert_contacts",
            "rule_name": "Alert Emergency Contacts",
            "triggered": triggered,
            "conditions_met": met,
            "conditions_failed": failed,
            "actual_values": {"escalation_count": self.escalation_count},
            "thresholds_used": {"escalation_count": thresh},
            "explanation": f"{'🚨 ALERTING CONTACTS' if triggered else 'Not alerting'}: {self.escalation_count} escalations"
        }
    
    def _in_cooldown(self, rule_id: str, minutes: int) -> bool:
        if rule_id not in self.last_action_times:
            return False
        elapsed = datetime.utcnow() - self.last_action_times[rule_id]
        return elapsed < timedelta(minutes=minutes)
    
    def _make_action(self, action: ActionType, evaluation: Dict) -> Dict:
        """Build action result with payload."""
        self.last_action_times[evaluation["rule_id"]] = datetime.utcnow()
        
        payloads = {
            ActionType.CALM_MODE: {
                "ui_mode": "calm",
                "message": "I've softened the interface. Take your time."
            },
            ActionType.SUGGEST_BREAK: {
                "options": ["5 min break", "Stretch", "Continue"],
                "message": "You've been working hard. A short break might help."
            },
            ActionType.SHOW_BREATHING: {
                "exercise": "box_breathing",
                "message": "Try this: breathe in 4s, hold 4s, out 4s, hold 4s."
            },
            ActionType.OFFER_SUPPORT: {
                "options": ["I'm okay", "Show tips", "Crisis help"],
                "message": "I'm here if you need support."
            },
            ActionType.SHOW_CRISIS_RESOURCES: {
                "hotlines": [{"name": "988 Crisis Line", "number": "988"}],
                "message": "Help is available 24/7. You're not alone."
            },
            ActionType.ALERT_CONTACTS: {
                "require_confirm": True,
                "message": "Would you like me to reach out to your support contacts?"
            }
        }
        
        return {
            "action": action.value,
            "triggered_by": evaluation,
            "timestamp": datetime.utcnow().isoformat(),
            "payload": payloads.get(action, {}),
            "why": evaluation["explanation"]
        }
    
    def update_threshold(self, name: str, value: float) -> Dict:
        """Let user update a threshold."""
        success = self.settings.set(name, value)
        return {
            "success": success,
            "threshold": name,
            "new_value": value if success else None,
            "all_thresholds": self.settings.thresholds
        }
    
    def get_history(self, limit: int = 20) -> List[Dict]:
        """Get action history with explanations."""
        return self.action_history[-limit:]
    
    def reset_escalation(self):
        """Reset after user acknowledges."""
        self.escalation_count = 0


# Session engines
_engines: Dict[str, RuleEngine] = {}

def get_engine(session_id: str) -> RuleEngine:
    if session_id not in _engines:
        _engines[session_id] = RuleEngine()
    return _engines[session_id]

def process_state(session_id: str, state: Dict, features: Dict) -> Dict:
    """Main entry: process through rule engine with full transparency."""
    engine = get_engine(session_id)
    return engine.evaluate(state, features)
