from sqlalchemy.orm import Session
from sqlalchemy import desc
from datetime import datetime
import uuid
import secrets
from typing import List, Optional

from .models import DBSession, DBSignal, DBState

def create_session(db: Session, user_id: Optional[str] = None) -> DBSession:
    """Create a new session with consent token."""
    consent_token = secrets.token_urlsafe(32)
    db_session = DBSession(
        id=uuid.uuid4(),
        consent_token=consent_token,
        user_id=user_id
    )
    db.add(db_session)
    db.commit()
    db.refresh(db_session)
    return db_session

def get_session_by_token(db: Session, token: str) -> Optional[DBSession]:
    """Get session by consent token."""
    return db.query(DBSession).filter(DBSession.consent_token == token).first()

def update_session_activity(db: Session, session_id: uuid.UUID):
    """Update session last_active timestamp."""
    db.query(DBSession).filter(DBSession.id == session_id).update(
        {"last_active": datetime.utcnow()}
    )
    db.commit()

def create_signal(db: Session, session_id: uuid.UUID, features: dict) -> DBSignal:
    """Store extracted signal features."""
    db_signal = DBSignal(
        session_id=session_id,
        dwell_mean=features.get("dwell_mean", 0.0),
        dwell_variance=features.get("dwell_variance", 0.0),
        flight_mean=features.get("flight_mean", 0.0),
        flight_variance=features.get("flight_variance", 0.0),
        error_rate=features.get("error_rate", 0.0),
        pause_mean=features.get("pause_mean", 0.0),
        chars_per_minute=features.get("chars_per_minute", 0.0),
        sentiment_score=features.get("sentiment_score", 0.0),
        text_length=features.get("text_length", 0),
        heat_index=features.get("heat_index", 0.0),
        rage_index=features.get("rage_index", 0.0),
        caps_ratio=features.get("caps_ratio", 0.0),
        rage_word_count=features.get("rage_word_count", 0)
    )
    db.add(db_signal)
    db.commit()
    db.refresh(db_signal)
    return db_signal

def get_recent_signals(db: Session, session_id: uuid.UUID, limit: int = 20) -> List[DBSignal]:
    """Get recent signals for baseline computation."""
    return db.query(DBSignal).filter(
        DBSignal.session_id == session_id
    ).order_by(desc(DBSignal.created_at)).limit(limit).all()

def compute_baseline(signals: List[DBSignal]) -> dict:
    """Compute baseline from recent signals."""
    if not signals:
        return None
    
    n = len(signals)
    return {
        "dwell_mean": sum(s.dwell_mean for s in signals) / n,
        "dwell_variance": sum(s.dwell_variance for s in signals) / n,
        "flight_mean": sum(s.flight_mean for s in signals) / n,
        "flight_variance": sum(s.flight_variance for s in signals) / n,
        "error_rate": sum(s.error_rate for s in signals) / n,
        "pause_mean": sum(s.pause_mean for s in signals) / n,
        "sentiment_score": sum(s.sentiment_score for s in signals) / n,
        "heat_index": sum(s.heat_index for s in signals) / n,
        "rage_index": sum(s.rage_index for s in signals) / n
    }

def create_state(db: Session, session_id: uuid.UUID, state: dict) -> DBState:
    """Store computed cognitive state."""
    db_state = DBState(
        session_id=session_id,
        cognitive_load=state.get("cognitive_load", 0.0),
        mood_drift=state.get("mood_drift", 0.0),
        decision_stability=state.get("decision_stability", 1.0),
        risk_volatility=state.get("risk_volatility", 0.0),
        sentiment_score=state.get("sentiment_score", 0.0),
        heat_index=state.get("heat_index", 0.0),
        rage_index=state.get("rage_index", 0.0)
    )
    db.add(db_state)
    db.commit()
    db.refresh(db_state)
    return db_state

def get_latest_state(db: Session, session_id: uuid.UUID) -> Optional[DBState]:
    """Get the most recent cognitive state."""
    return db.query(DBState).filter(
        DBState.session_id == session_id
    ).order_by(desc(DBState.created_at)).first()
