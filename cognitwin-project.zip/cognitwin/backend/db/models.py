from sqlalchemy import Column, String, Float, Integer, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
from datetime import datetime
import uuid

from .database import Base

class DBSession(Base):
    __tablename__ = "sessions"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    consent_token = Column(String(255), nullable=False, unique=True)
    user_id = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_active = Column(DateTime, default=datetime.utcnow)
    
    signals = relationship("DBSignal", back_populates="session")
    states = relationship("DBState", back_populates="session")

class DBSignal(Base):
    __tablename__ = "signals"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(UUID(as_uuid=True), ForeignKey("sessions.id"))
    dwell_mean = Column(Float, default=0.0)
    dwell_variance = Column(Float, default=0.0)
    flight_mean = Column(Float, default=0.0)
    flight_variance = Column(Float, default=0.0)
    error_rate = Column(Float, default=0.0)
    pause_mean = Column(Float, default=0.0)
    chars_per_minute = Column(Float, default=0.0)
    sentiment_score = Column(Float, default=0.0)
    text_length = Column(Integer, default=0)
    # Heat & Rage signals
    heat_index = Column(Float, default=0.0)
    rage_index = Column(Float, default=0.0)
    caps_ratio = Column(Float, default=0.0)
    rage_word_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    session = relationship("DBSession", back_populates="signals")

class DBState(Base):
    __tablename__ = "states"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(UUID(as_uuid=True), ForeignKey("sessions.id"))
    cognitive_load = Column(Float, default=0.0)
    mood_drift = Column(Float, default=0.0)
    decision_stability = Column(Float, default=1.0)
    risk_volatility = Column(Float, default=0.0)
    sentiment_score = Column(Float, default=0.0)
    # Heat & Rage state
    heat_index = Column(Float, default=0.0)
    rage_index = Column(Float, default=0.0)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    session = relationship("DBSession", back_populates="states")
