import numpy as np
from typing import Optional

def normalize(value: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """Clip and normalize value to 0-1 range."""
    if max_val == min_val:
        return 0.5
    normalized = (value - min_val) / (max_val - min_val + 1e-6)
    return max(0.0, min(1.0, normalized))

def compute_cognitive_state(features: dict, baseline: Optional[dict] = None) -> dict:
    """
    Compute cognitive state vector from extracted features.
    
    All formulas are deterministic and explainable - no ML black boxes.
    
    Returns:
        cognitive_load: 0-1 (higher = more loaded)
        mood_drift: -1 to 1 (negative = worse mood)
        decision_stability: 0-1 (higher = more stable)
        risk_volatility: 0-1 (higher = more volatile/risky)
        heat_index: 0-1 (emotional intensity)
        rage_index: 0-1 (anger/frustration level)
    """
    
    # Default baseline if none provided
    if baseline is None:
        baseline = {
            "dwell_mean": 100.0,
            "dwell_variance": 500.0,
            "flight_mean": 150.0,
            "flight_variance": 1000.0,
            "error_rate": 0.05,
            "pause_mean": 300.0,
            "sentiment_score": 0.0,
            "heat_index": 0.0,
            "rage_index": 0.0
        }
    
    # === 1. COGNITIVE LOAD ===
    # Higher flight variance + error rate + pauses = higher cognitive load
    # Heat and rage also contribute to cognitive load
    
    flight_var_norm = normalize(features["flight_variance"], 0, 5000)
    error_norm = normalize(features["error_rate"], 0, 0.3)
    pause_norm = normalize(features["pause_mean"], 0, 2000)
    heat_contribution = features.get("heat_index", 0.0) * 0.15
    
    cognitive_load = (
        0.35 * flight_var_norm +
        0.30 * error_norm +
        0.20 * pause_norm +
        heat_contribution
    )
    
    # === 2. MOOD DRIFT ===
    # Current sentiment minus baseline sentiment
    # Rage pulls mood negative
    
    current_sentiment = features.get("sentiment_score", 0.0)
    baseline_sentiment = baseline.get("sentiment_score", 0.0)
    rage_penalty = features.get("rage_index", 0.0) * 0.5
    
    mood_drift = current_sentiment - baseline_sentiment - rage_penalty
    mood_drift = max(-1.0, min(1.0, mood_drift))
    
    # === 3. DECISION STABILITY ===
    # Lower volatility + lower heat/rage = more stable decisions
    
    typing_volatility = abs(features["flight_variance"] - baseline["flight_variance"]) / max(baseline["flight_variance"], 1)
    sentiment_volatility = abs(mood_drift)
    heat_factor = features.get("heat_index", 0.0)
    
    epsilon = 0.1
    raw_stability = 1.0 / (typing_volatility + sentiment_volatility + heat_factor + epsilon)
    decision_stability = normalize(raw_stability, 0, 5)
    
    # === 4. RISK VOLATILITY ===
    # Combines: mood drift + error bursts + tempo changes + heat + rage
    
    error_burst = 1.0 if features["error_rate"] > 2 * baseline["error_rate"] else 0.0
    tempo_spike = 1.0 if features["flight_variance"] > 2 * baseline["flight_variance"] else 0.0
    heat_index = features.get("heat_index", 0.0)
    rage_index = features.get("rage_index", 0.0)
    
    risk_volatility = normalize(
        abs(mood_drift) * 0.25 +
        error_burst * 0.15 +
        tempo_spike * 0.15 +
        heat_index * 0.20 +
        rage_index * 0.25,
        0, 1
    )
    
    # === 5. HEAT INDEX ===
    # Already computed in features, but can be adjusted based on baseline
    heat_index = features.get("heat_index", 0.0)
    baseline_heat = baseline.get("heat_index", 0.0)
    
    # Relative heat (compared to user's baseline)
    relative_heat = min(1.0, heat_index + (heat_index - baseline_heat) * 0.3)
    
    # === 6. RAGE INDEX ===
    # Already computed in features, but can be adjusted based on baseline
    rage_index = features.get("rage_index", 0.0)
    baseline_rage = baseline.get("rage_index", 0.0)
    
    # Relative rage (compared to user's baseline)
    relative_rage = min(1.0, rage_index + (rage_index - baseline_rage) * 0.3)
    
    return {
        "cognitive_load": round(cognitive_load, 3),
        "mood_drift": round(mood_drift, 3),
        "decision_stability": round(decision_stability, 3),
        "risk_volatility": round(risk_volatility, 3),
        "heat_index": round(max(0, relative_heat), 3),
        "rage_index": round(max(0, relative_rage), 3),
        "sentiment_score": round(current_sentiment, 3)
    }
