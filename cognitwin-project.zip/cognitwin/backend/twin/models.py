from pydantic import BaseModel
from typing import List, Optional

class KeystrokeSignal(BaseModel):
    timestamp: float
    key: Optional[str] = None
    event_type: str  # "keydown" or "keyup"
    dwell_ms: Optional[float] = None
    flight_ms: Optional[float] = None

class ConsentRequest(BaseModel):
    user_id: Optional[str] = None

class ConsentResponse(BaseModel):
    session_id: str
    consent_token: str
    created_at: str

class IngestRequest(BaseModel):
    session_id: str
    signals: List[KeystrokeSignal]
    text_snapshot: Optional[str] = ""

class IngestResponse(BaseModel):
    status: str
    signals_received: int
    state_updated: bool

class StateResponse(BaseModel):
    session_id: str
    timestamp: str
    cognitive_load: float
    mood_drift: float
    decision_stability: float
    risk_volatility: float
    heat_index: float = 0.0
    rage_index: float = 0.0

class HealthResponse(BaseModel):
    status: str
    service: str
