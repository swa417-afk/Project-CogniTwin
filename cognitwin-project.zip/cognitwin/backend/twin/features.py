import numpy as np
import re
from typing import List, Optional
from textblob import TextBlob

# Rage/frustration indicator words
RAGE_WORDS = {
    'fuck', 'fucking', 'shit', 'damn', 'hell', 'ass', 'bastard', 'crap',
    'hate', 'stupid', 'idiot', 'dumb', 'annoying', 'ridiculous', 'terrible',
    'awful', 'horrible', 'worst', 'sucks', 'useless', 'pathetic', 'garbage',
    'bullshit', 'wtf', 'omg', 'ugh', 'argh', 'grrr', 'ffs', 'smh'
}

# Intensity amplifiers
AMPLIFIERS = {'very', 'really', 'so', 'extremely', 'absolutely', 'totally', 'completely'}


def detect_heat_signals(text: str) -> dict:
    """
    Detect "heat" (emotional intensity) from text patterns.
    
    Returns:
        caps_ratio: Proportion of uppercase letters (shouting)
        exclamation_density: Exclamation marks per 100 chars
        question_density: Question marks per 100 chars (confusion/frustration)
        repeated_chars: Count of repeated characters (nooooo, whyyyy)
        repeated_punctuation: Count of repeated punctuation (!!!, ???)
    """
    if not text or len(text) < 5:
        return {
            "caps_ratio": 0.0,
            "exclamation_density": 0.0,
            "question_density": 0.0,
            "repeated_chars": 0,
            "repeated_punctuation": 0
        }
    
    # Caps ratio (excluding spaces and punctuation)
    letters = [c for c in text if c.isalpha()]
    caps_count = sum(1 for c in letters if c.isupper())
    caps_ratio = caps_count / max(len(letters), 1)
    
    # Punctuation density (per 100 characters)
    text_len = len(text)
    exclamation_count = text.count('!')
    question_count = text.count('?')
    exclamation_density = (exclamation_count / text_len) * 100
    question_density = (question_count / text_len) * 100
    
    # Repeated characters (3+ of same char: nooooo, whyyyy)
    repeated_chars = len(re.findall(r'(.)\1{2,}', text))
    
    # Repeated punctuation (!!! or ???)
    repeated_punctuation = len(re.findall(r'[!?]{2,}', text))
    
    return {
        "caps_ratio": round(caps_ratio, 3),
        "exclamation_density": round(exclamation_density, 3),
        "question_density": round(question_density, 3),
        "repeated_chars": repeated_chars,
        "repeated_punctuation": repeated_punctuation
    }


def detect_rage_signals(text: str) -> dict:
    """
    Detect "rage" (anger/frustration) from text content.
    
    Returns:
        rage_word_count: Number of rage-indicating words
        rage_word_ratio: Rage words as proportion of total words
        amplifier_count: Intensity amplifiers used
        negative_intensity: Combined negativity score (0-1)
    """
    if not text or len(text) < 5:
        return {
            "rage_word_count": 0,
            "rage_word_ratio": 0.0,
            "amplifier_count": 0,
            "negative_intensity": 0.0
        }
    
    # Tokenize (simple split, lowercase)
    words = re.findall(r'\b\w+\b', text.lower())
    total_words = max(len(words), 1)
    
    # Count rage words
    rage_word_count = sum(1 for w in words if w in RAGE_WORDS)
    rage_word_ratio = rage_word_count / total_words
    
    # Count amplifiers (very, really, so, etc.)
    amplifier_count = sum(1 for w in words if w in AMPLIFIERS)
    
    # Get sentiment for intensity calculation
    try:
        blob = TextBlob(text)
        polarity = blob.sentiment.polarity  # -1 to 1
        # Convert negative polarity to intensity (0 to 1)
        negative_intensity = max(0, -polarity)
    except:
        negative_intensity = 0.0
    
    # Boost intensity if rage words present
    if rage_word_count > 0:
        negative_intensity = min(1.0, negative_intensity + (rage_word_ratio * 0.5))
    
    return {
        "rage_word_count": rage_word_count,
        "rage_word_ratio": round(rage_word_ratio, 3),
        "amplifier_count": amplifier_count,
        "negative_intensity": round(negative_intensity, 3)
    }


def detect_typing_agitation(signals: List[dict], dwell_times: List[float], flight_times: List[float]) -> dict:
    """
    Detect agitation from typing dynamics.
    
    Agitation signals:
    - Accelerating typing speed (flight times getting shorter)
    - Harder key presses (longer dwell times)
    - Erratic rhythm (high variance)
    - Error bursts (multiple corrections in sequence)
    """
    if not signals or len(signals) < 5:
        return {
            "speed_acceleration": 0.0,
            "keystroke_intensity": 0.0,
            "rhythm_chaos": 0.0,
            "error_burst_count": 0
        }
    
    # Speed acceleration: compare first half vs second half flight times
    if len(flight_times) >= 4:
        mid = len(flight_times) // 2
        first_half_avg = np.mean(flight_times[:mid])
        second_half_avg = np.mean(flight_times[mid:])
        # Negative = getting faster (more agitated)
        if first_half_avg > 0:
            speed_acceleration = (first_half_avg - second_half_avg) / first_half_avg
        else:
            speed_acceleration = 0.0
    else:
        speed_acceleration = 0.0
    
    # Keystroke intensity: longer dwell = harder press
    # Normalize against typical dwell (80-120ms)
    if dwell_times:
        avg_dwell = np.mean(dwell_times)
        keystroke_intensity = min(1.0, max(0.0, (avg_dwell - 80) / 100))
    else:
        keystroke_intensity = 0.0
    
    # Rhythm chaos: coefficient of variation of flight times
    if flight_times and len(flight_times) > 2:
        flight_std = np.std(flight_times)
        flight_mean = np.mean(flight_times)
        if flight_mean > 0:
            rhythm_chaos = min(1.0, flight_std / flight_mean)
        else:
            rhythm_chaos = 0.0
    else:
        rhythm_chaos = 0.0
    
    # Error bursts: consecutive backspaces/deletes
    error_keys = {"Backspace", "Delete"}
    error_burst_count = 0
    consecutive_errors = 0
    for s in signals:
        if s.key in error_keys:
            consecutive_errors += 1
            if consecutive_errors >= 3:
                error_burst_count += 1
                consecutive_errors = 0
        else:
            consecutive_errors = 0
    
    return {
        "speed_acceleration": round(speed_acceleration, 3),
        "keystroke_intensity": round(keystroke_intensity, 3),
        "rhythm_chaos": round(rhythm_chaos, 3),
        "error_burst_count": error_burst_count
    }


def compute_heat_index(heat_signals: dict, agitation: dict) -> float:
    """
    Compute overall "heat" index (0-1).
    Heat = emotional intensity without necessarily being negative.
    """
    heat = (
        heat_signals["caps_ratio"] * 0.25 +
        min(1.0, heat_signals["exclamation_density"] / 5) * 0.2 +
        min(1.0, heat_signals["repeated_punctuation"] / 3) * 0.15 +
        agitation["speed_acceleration"] * 0.2 +
        agitation["rhythm_chaos"] * 0.2
    )
    return round(min(1.0, max(0.0, heat)), 3)


def compute_rage_index(rage_signals: dict, heat_signals: dict, agitation: dict) -> float:
    """
    Compute overall "rage" index (0-1).
    Rage = heat + negative emotional content.
    """
    rage = (
        rage_signals["negative_intensity"] * 0.3 +
        rage_signals["rage_word_ratio"] * 5 * 0.2 +  # Amplify rage word impact
        heat_signals["caps_ratio"] * 0.15 +
        min(1.0, agitation["error_burst_count"] / 3) * 0.15 +
        agitation["keystroke_intensity"] * 0.1 +
        agitation["speed_acceleration"] * 0.1
    )
    return round(min(1.0, max(0.0, rage)), 3)


def extract_features(signals: List[dict], text_snapshot: Optional[str] = "") -> dict:
    """
    Extract features from a batch of keystroke signals.
    
    Returns derived features only - never stores raw keystrokes.
    Includes heat and rage detection.
    """
    if not signals:
        return {
            "dwell_mean": 0.0,
            "dwell_variance": 0.0,
            "flight_mean": 0.0,
            "flight_variance": 0.0,
            "error_rate": 0.0,
            "pause_mean": 0.0,
            "chars_per_minute": 0.0,
            "sentiment_score": 0.0,
            "text_length": 0,
            "heat_index": 0.0,
            "rage_index": 0.0
        }
    
    # Extract dwell times (filter None values)
    dwell_times = [s.dwell_ms for s in signals if s.dwell_ms is not None]
    flight_times = [s.flight_ms for s in signals if s.flight_ms is not None]
    
    # Count backspaces/deletes as errors
    error_keys = ["Backspace", "Delete"]
    error_count = sum(1 for s in signals if s.key in error_keys)
    total_keys = len(signals)
    
    # Find long pauses (> 500ms flight time)
    pauses = [f for f in flight_times if f > 500]
    
    # Calculate timing window for chars per minute
    if signals:
        timestamps = [s.timestamp for s in signals]
        duration_sec = max(timestamps) - min(timestamps) if len(timestamps) > 1 else 1
        duration_min = max(duration_sec / 60, 0.01)
        chars_per_minute = (total_keys - error_count) / duration_min
    else:
        chars_per_minute = 0.0
    
    # Sentiment analysis on text snapshot
    sentiment_score = 0.0
    if text_snapshot and len(text_snapshot) > 10:
        try:
            blob = TextBlob(text_snapshot)
            sentiment_score = blob.sentiment.polarity
        except:
            sentiment_score = 0.0
    
    # === HEAT & RAGE DETECTION ===
    heat_signals = detect_heat_signals(text_snapshot or "")
    rage_signals = detect_rage_signals(text_snapshot or "")
    agitation = detect_typing_agitation(signals, dwell_times, flight_times)
    
    heat_index = compute_heat_index(heat_signals, agitation)
    rage_index = compute_rage_index(rage_signals, heat_signals, agitation)
    
    return {
        # Base features
        "dwell_mean": float(np.mean(dwell_times)) if dwell_times else 0.0,
        "dwell_variance": float(np.var(dwell_times)) if dwell_times else 0.0,
        "flight_mean": float(np.mean(flight_times)) if flight_times else 0.0,
        "flight_variance": float(np.var(flight_times)) if flight_times else 0.0,
        "error_rate": error_count / max(total_keys, 1),
        "pause_mean": float(np.mean(pauses)) if pauses else 0.0,
        "chars_per_minute": chars_per_minute,
        "sentiment_score": sentiment_score,
        "text_length": len(text_snapshot) if text_snapshot else 0,
        
        # Heat & Rage
        "heat_index": heat_index,
        "rage_index": rage_index,
        
        # Detailed signals (for debugging/explainability)
        "caps_ratio": heat_signals["caps_ratio"],
        "exclamation_density": heat_signals["exclamation_density"],
        "rage_word_count": rage_signals["rage_word_count"],
        "speed_acceleration": agitation["speed_acceleration"],
        "rhythm_chaos": agitation["rhythm_chaos"],
        "error_burst_count": agitation["error_burst_count"]
    }
