from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import Optional
import uuid

from db.database import engine, get_db, Base
from db import crud, models as db_models
from twin.models import ConsentRequest, ConsentResponse, IngestRequest, IngestResponse, StateResponse
from twin.features import extract_features
from twin.state import compute_cognitive_state
from agent.rule_engine import get_engine, process_state

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(title="CogniTwin", description="Cognitive digital twin with transparent rule-based agent")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "cognitwin", "agent": "rule_engine_v2"}

@app.post("/consent", response_model=ConsentResponse)
def create_consent(request: ConsentRequest, db: Session = Depends(get_db)):
    """Create a new session with consent token."""
    session = crud.create_session(db, user_id=request.user_id)
    return ConsentResponse(
        session_id=str(session.id),
        consent_token=session.consent_token,
        created_at=session.created_at.isoformat()
    )

@app.post("/ingest")
def ingest_signals(
    request: IngestRequest,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
):
    """
    Ingest keystroke signals → compute state → run through rule engine.
    
    Returns full transparency: all rule evaluations with values vs thresholds.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    token = authorization.replace("Bearer ", "")
    session = crud.get_session_by_token(db, token)
    
    if not session or str(session.id) != request.session_id:
        raise HTTPException(status_code=403, detail="Invalid session or token")
    
    # Extract features
    features = extract_features(request.signals, request.text_snapshot)
    
    # Store features
    crud.create_signal(db, session_id=session.id, features=features)
    
    # Compute baseline from history
    recent_signals = crud.get_recent_signals(db, session_id=session.id, limit=20)
    baseline = crud.compute_baseline(recent_signals) if len(recent_signals) > 5 else None
    
    # Compute cognitive state
    state = compute_cognitive_state(features, baseline)
    
    # Store state
    crud.create_state(db, session_id=session.id, state=state)
    crud.update_session_activity(db, session_id=session.id)
    
    # === TRANSPARENT RULE ENGINE ===
    # Returns full explanation: what triggered, why, values vs thresholds
    agent_result = process_state(
        session_id=request.session_id,
        state=state,
        features=features
    )
    
    return {
        "status": "ok",
        "signals_received": len(request.signals),
        "state": state,
        "agent": agent_result
    }

@app.get("/state/{session_id}")
def get_state(
    session_id: str,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
):
    """Get latest cognitive state + rule engine evaluation."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    token = authorization.replace("Bearer ", "")
    session = crud.get_session_by_token(db, token)
    
    if not session or str(session.id) != session_id:
        raise HTTPException(status_code=403, detail="Invalid session or token")
    
    state = crud.get_latest_state(db, session_id=session.id)
    
    if not state:
        return {
            "session_id": session_id,
            "timestamp": session.created_at.isoformat(),
            "cognitive_load": 0.0,
            "mood_drift": 0.0,
            "decision_stability": 1.0,
            "risk_volatility": 0.0,
            "heat_index": 0.0,
            "rage_index": 0.0,
            "agent": None
        }
    
    # Get current rule evaluation
    cognitive_state = {
        "cognitive_load": state.cognitive_load,
        "mood_drift": state.mood_drift,
        "decision_stability": state.decision_stability,
        "risk_volatility": state.risk_volatility,
        "heat_index": state.heat_index,
        "rage_index": state.rage_index
    }
    
    agent_result = process_state(session_id, cognitive_state, {})
    
    return {
        "session_id": session_id,
        "timestamp": state.created_at.isoformat(),
        **cognitive_state,
        "agent": agent_result
    }

@app.get("/agent/{session_id}/settings")
def get_settings(
    session_id: str,
    authorization: Optional[str] = Header(None)
):
    """Get user's thresholds and rule settings."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    engine = get_engine(session_id)
    return {
        "settings": engine.settings.to_dict(),
        "escalation_count": engine.escalation_count
    }

@app.post("/agent/{session_id}/threshold")
def update_threshold(
    session_id: str,
    name: str,
    value: float,
    authorization: Optional[str] = Header(None)
):
    """
    Update a user threshold.
    
    Example: POST /agent/xxx/threshold?name=rage_high&value=0.8
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    engine = get_engine(session_id)
    result = engine.update_threshold(name, value)
    return result

@app.get("/agent/{session_id}/history")
def get_history(
    session_id: str,
    authorization: Optional[str] = Header(None)
):
    """
    Get action history with full explanations.
    
    Shows: what action, why it triggered, exact values vs thresholds.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    engine = get_engine(session_id)
    return {
        "history": engine.get_history(limit=50),
        "escalation_count": engine.escalation_count
    }

@app.post("/agent/{session_id}/acknowledge")
def acknowledge(
    session_id: str,
    authorization: Optional[str] = Header(None)
):
    """User acknowledges - reset escalation counter."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    engine = get_engine(session_id)
    engine.reset_escalation()
    return {"status": "ok", "escalation_count": 0}

@app.get("/agent/{session_id}/explain")
def explain(
    session_id: str,
    authorization: Optional[str] = Header(None),
    db: Session = Depends(get_db)
):
    """
    Full transparency view: current values vs all thresholds.
    
    Shows exactly what would/wouldn't trigger and why.
    """
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing authorization token")
    
    token = authorization.replace("Bearer ", "")
    session = crud.get_session_by_token(db, token)
    
    if not session or str(session.id) != session_id:
        raise HTTPException(status_code=403, detail="Invalid session or token")
    
    state = crud.get_latest_state(db, session_id=session.id)
    engine = get_engine(session_id)
    
    if not state:
        return {"error": "No state data yet"}
    
    # Build comparison table
    thresholds = engine.settings.thresholds
    current = {
        "cognitive_load": state.cognitive_load,
        "mood_drift": state.mood_drift,
        "decision_stability": state.decision_stability,
        "risk_volatility": state.risk_volatility,
        "heat_index": state.heat_index,
        "rage_index": state.rage_index
    }
    
    comparisons = []
    for name, value in current.items():
        # Find relevant thresholds
        relevant = {k: v for k, v in thresholds.items() if name.split("_")[0] in k}
        comparisons.append({
            "metric": name,
            "current_value": round(value, 3),
            "thresholds": {k: thresholds[k] for k in relevant}
        })
    
    return {
        "session_id": session_id,
        "current_values": current,
        "thresholds": thresholds,
        "comparisons": comparisons,
        "escalation_count": engine.escalation_count
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
