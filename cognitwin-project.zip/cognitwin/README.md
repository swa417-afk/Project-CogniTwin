# CogniTwin

> Real-time cognitive digital twin that models your mental state from typing behavior.

![CogniTwin Logo](./cognitwin_logo.png)

## Quick Start

```bash
# Clone and run
git clone https://github.com/yourusername/cognitwin.git
cd cognitwin
docker compose up --build
```

Open http://localhost:3000

## What It Does

CogniTwin captures passive signals as you type and computes:

| Metric | Description | Range |
|--------|-------------|-------|
| **Cognitive Load** | Mental effort required | 0-100% |
| **Mood Drift** | Change from baseline | -1 to +1 |
| **Decision Stability** | Behavioral consistency | 0-100% |
| **Risk Volatility** | Irregularity signals | 0-100% |
| **🔥 Heat Index** | Emotional intensity | 0-100% |
| **😤 Rage Index** | Frustration/anger level | 0-100% |

## Features

### 📊 Real-Time Monitoring
- Keystroke dynamics analysis (dwell time, flight time)
- Text sentiment and rage word detection
- Typing pattern agitation detection
- Live updating dashboard

### 📓 Behavior Diary
- Log daily mood and activities
- Auto-capture cognitive snapshots
- Weekly mood summaries
- Activity tagging

### 🆘 Crisis Support
- Pre-installed suicide hotlines (988, Crisis Text Line, etc.)
- Add 3-5 personal support contacts
- One-tap calling/texting
- Emergency access even when locked

### 🔒 Privacy Lock
- Optional PIN protection
- Emergency bypass for crisis resources
- Data stored locally

## How It Works

**Signals captured:**
- Keystroke timing (dwell time, flight time)
- Error rate (backspaces/corrections)
- Pause intervals
- Text sentiment
- CAPS/exclamation patterns
- Rage word detection

**Privacy first:**
- Only derived features stored
- Never raw keystrokes
- Never full text content

## Tech Stack

- **Backend:** FastAPI + PostgreSQL + SQLAlchemy
- **Frontend:** React + Vite + TailwindCSS
- **Deployment:** Docker Compose

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/consent` | POST | Create session |
| `/ingest` | POST | Send keystroke signals |
| `/state/{id}` | GET | Get cognitive state |
| `/health` | GET | Health check |

## Development

```bash
# Backend only
cd backend
pip install -r requirements.txt
uvicorn main:app --reload

# Frontend only
cd frontend
npm install
npm run dev
```

## License

MIT
