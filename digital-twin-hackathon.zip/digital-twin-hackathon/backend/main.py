from fastapi import FastAPI

app = FastAPI(title="User Digital Twin Hackathon")

@app.get("/health")
def health():
    return {"status": "ok"}
