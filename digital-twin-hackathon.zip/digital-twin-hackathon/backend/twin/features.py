def compute_demo_state(signal):
    dwell = signal.get("dwell_mean_ms", 0)
    error_rate = signal.get("error_rate", 0)
    sentiment = signal.get("sentiment", 0)

    cognitive_load = min(1.0, (error_rate * 2) + (abs(dwell - 120) / 200))
    mood_drift = abs(sentiment)
    decision_stability = max(0.0, 1 - cognitive_load)
    risk_volatility = min(1.0, mood_drift + error_rate)

    return {
        "cognitive_load": cognitive_load,
        "mood_drift": mood_drift,
        "decision_stability": decision_stability,
        "risk_volatility": risk_volatility
    }
