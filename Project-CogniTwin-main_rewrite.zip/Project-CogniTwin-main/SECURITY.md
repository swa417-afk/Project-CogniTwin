# Security Policy

- Do not commit secrets.
- Use environment variables for configuration.
- Keep dependencies updated.

## Reporting
If you find a vulnerability, report it privately to the maintainer.
